# Tracker base count-forms supplement notes (revision 2)

Editorial-only appendix for the accepted RU/EN/ES/FR/pt-BR/DE/IT base. Base translations and source are untouched. The JSON contains the complete overlay and all requested sample renders. This revision corrects the earlier incomplete summary of CLDR cardinal categories and adds the 1,000,000 sample.

## Provenance and guardrails

- Source manifest: `translation-units.json` — SHA-256 `285e196dac220a2d3e95ffed48034bc04713d7e29995d8b8aedf7cb3e4cf6324`.
- Source repository baseline: `8Dionysus/not-ai-time-tracker` at `ee0ab1f52d07c9957f9a198312d6584aebc9d170`.
- Semantic context reviewed: `translation-semantic-context.json`; no entry was specific to these four keys.
- Reviewed base inputs: `translations-en.json`, `translations-es.json`, `translations-fr.json`, `translations-pt-BR.json`, `translations-de.json`, `translations-it.json` plus the RU source units.
- Input type/restrictions: use each typed numeric placeholder directly as a nonnegative integer (minutes or collection size). Zero is allowed. Fractions/decimals are out of scope. Never recover counts by parsing display text.
- This is an editorial overlay only. It does not modify source/base files or claim current runtime plural/category/number-formatting support. Preserve draft keys, semantic names, occurrence IDs and placeholders. `$title` is already-localized UI text; pass it through unchanged.
- All sample numbers are substituted as ASCII digits exactly as shown, including ungrouped `1000000`. No number grouping or localized-digit formatter is implied.
- Source digests appear in the JSON as SHA-256 of exact source text UTF-8 and SHA-256 of compact JSON UTF-8 array `[source_text]` (the latter matches ES/pt-BR draft hash convention).

## CLDR 49 categories vs. editorial surface forms

The two-form lists below are editorial grammatical surface groups; they are not complete listings of every CLDR cardinal category. CLDR 49 has `many` for es, fr, pt, and it at positive integral multiples of 1,000,000. For these noun templates, CLDR `many` maps to the same plural surface template as `other`. Exact conditions, category-to-surface maps, and unknown-category fallback are recorded per locale in the JSON.

- `en`: CLDR `one` iff `n=1`; `other` otherwise for nonnegative integral counts. No cardinal `many` in CLDR 49.
- `de`: CLDR `one` iff `n=1`; `other` otherwise for nonnegative integral counts. No cardinal `many` in CLDR 49.
- `es`: CLDR `one` iff `n=1`; `many` for positive integers where `n % 1,000,000 = 0`; `other` otherwise. Map `many` → plural surface (`other`).
- `fr`: CLDR `one` for `n=0` or `1`; `many` for positive integers where `n % 1,000,000 = 0`; `other` otherwise. Map `many` → plural surface (`other`).
- `pt-BR`: CLDR locale `pt`: `one` for `n=0` or `1`; `many` for positive integers where `n % 1,000,000 = 0`; `other` otherwise. Map `many` → plural surface (`other`).
- `it`: CLDR `one` iff `n=1`; `many` for positive integers where `n % 1,000,000 = 0`; `other` otherwise. Map `many` → plural surface (`other`).
- `ru`: CLDR `one` iff `n % 10=1` and `n % 100!=11`; `few` iff `n % 10∈2..4` and `n % 100∉12..14`; `many` for the remaining nonnegative integers. Forms are one/few/many.
- Defensive fallback: if a selector yields an unknown category, use the locale plural/default surface (`many` for Russian) and interpolate the existing numeric placeholder unchanged. For CLDR `many` in es/fr/pt-BR/it, select the same plural surface as `other`. Do not drop or parse the count. This is guidance, not an implementation claim.
- CLDR source: [Unicode CLDR 49 Language Plural Rules](https://unicode.org/cldr/charts/49/supplemental/language_plural_rules.html). It documents the locale-specific category sets and million-count `many` category.
- Zero notes: French uses singular after zéro; see [Le Robert](https://dictionnaire.lerobert.com/guide/accord-du-nom-apres-zero). Brazilian Portuguese singular-after-zero usage is documented in [Ciberdúvidas](https://ciberduvidas.iscte-iul.pt/consultorio/perguntas/o-uso-de-zero-com-nomes).

## Correction history

- Revision 1 JSON SHA-256: `1d3ec1130c8145276439eb93c939a16fd5a55f359b554ed048e97c8a5714b514`; notes SHA-256: `a1eff446ac7490795848c2c6d59367f1da254c2f60832256f98bb3b3d83ec5d4`.
- Revision 2 addresses the incomplete CLDR summary, maps CLDR `many` to plural surface for es/fr/pt-BR/it, adds `1000000` samples and an unknown-category fallback that keeps the count, and clarifies number-rendering limits.
- No source or base translation was changed. The original source-manifest SHA-256 remains `285e196dac220a2d3e95ffed48034bc04713d7e29995d8b8aedf7cb3e4cf6324`.

## Per-key source anchors and conditions

### `tracker.draft.98eec670693ec0194f31` — accessibility_label.1ddd051d9e
- Source: `$minutes мин`; raw SHA-256 `836a7112ba0507fcffe046c55268239c2dddc21238ae4c180cf570434cd645fd`; compact-array SHA-256 `34d1eb54f1b56512a76e768645d3daab730e3c6d032a7afdc8cec09c5f3206d3`.
- Occurrence: `UI-95f4e02c-13c3d9-L0286-C014` at `app/src/main/kotlin/dev/notai/tracker/android/ui/SettingsScreen.kt:286:14` (blob `13c3d95d240d3252857fe6dc62f5e1e3a4fffc59`).
- Decision: All six base translations and the Russian source use the short unit abbreviation min/Min.; in this unit-expression use the abbreviated unit is invariant with count. No singular/plural variants are editorially necessary.
- Input: `$minutes`; nonnegative integral minute count; zero included for samples; no upper cap inferred.
- Exact CLDR category → editorial surface map and unknown-category fallback: per-locale `forms_by_locale` or `unknown_category_fallback` fields in the JSON.

### `tracker.draft.5a09492140c306c89726` — accessibility_label.a4135d5764
- Source: `$title: $minutes минут`; raw SHA-256 `f3029d395a1332bdb5a8feddc61e0559b3a4f6ab24b977d235270b06c50c9ab8`; compact-array SHA-256 `256fa64a19b9d7a02cd438f8ab846c37510d72f68a7873c88f9feaff8b5ceb26`.
- Occurrence: `UI-95f4e02c-13c3d9-L0286-C093` at `app/src/main/kotlin/dev/notai/tracker/android/ui/SettingsScreen.kt:286:93` (blob `13c3d95d240d3252857fe6dc62f5e1e3a4fffc59`).
- Decision: English base keeps min abbreviated and is invariant. Russian, Spanish, French, Brazilian Portuguese, German and Italian spell the counted noun and need the indicated grammatical forms.
- Input: `$minutes`; nonnegative integral minute count; zero included for samples; no upper cap inferred.
- Exact CLDR category → editorial surface map and unknown-category fallback: per-locale `forms_by_locale` or `unknown_category_fallback` fields in the JSON.

English uses fixed `min`; other locales use spelled-out forms. Russian has one/few/many; Spanish/FR/PT-BR/DE/IT select singular where stated and plural otherwise. In fr/pt-BR the CLDR `many` category maps to the plural template, same as `other`.

### `tracker.draft.5ea449e59ed7e444a666` — action_label.1f09d9fea5
- Source: `Фокус: ${home?.focusMinutes ?: 25} мин работы`; raw SHA-256 `b2ded4247e12eab3b05c84b1b66755921924ee38c50eccb1b40499619d32e84c`; compact-array SHA-256 `1c9c969785854cf7e803f7edc1b35bfad648385ddd1b5dc71610e50465126a4f`.
- Occurrence: `UI-7fe04470-17e873-L0158-C024` at `app/src/main/kotlin/dev/notai/tracker/android/ui/TimerScreen.kt:158:24` (blob `17e873c0af2df99ca3c1f85b59664c14883834f8`).
- Decision: All base translations retain the abbreviated time unit min/Min.; the unit abbreviation is invariant in these phrases, so no count-specific noun forms are needed.
- Input: `${home?.focusMinutes ?: 25}`; nonnegative integral minute count; the source fallback is 25; no other runtime bounds inferred.
- Exact CLDR category → editorial surface map and unknown-category fallback: per-locale `forms_by_locale` or `unknown_category_fallback` fields in the JSON.

### `tracker.draft.43196b99adb515ba000e` — display_text.b701c5df21
- Source: `Ещё ${d.moreAreas.size} областей: профессии и работа`; raw SHA-256 `d0ad6b63467b6bdbf7ff7631c92cc139b8527a3de5949dc4c59674add4c1cf30`; compact-array SHA-256 `8011671a29eeeb4dd5da95b74d5ccf269c38753f61df1281ceed79fee91c51c9`.
- Occurrence: `UI-4b1b159c-c4a72b-L0176-C042` at `app/src/main/kotlin/dev/notai/tracker/android/ui/PickerSheet.kt:176:42` (blob `c4a72ba6d2b1fc6b3851a62b9dad17cbefb66690`).
- Decision: The localized noun for area/area-equivalent changes number. The singular German and Italian variants also move the adjective to preserve natural agreement.
- Input: `${d.moreAreas.size}`; nonnegative integral collection size; zero included; no upper cap inferred.
- Exact CLDR category → editorial surface map and unknown-category fallback: per-locale `forms_by_locale` or `unknown_category_fallback` fields in the JSON.

German and Italian singular templates reorder the adjective/noun (`1 weiterer Bereich`, `1 altra area`) for natural agreement. For Spanish, French, pt-BR, German and Italian, CLDR `many` at 1,000,000 maps to the plural template.

## Sample renders — `tracker.draft.98eec670693ec0194f31`

Counts in order: `0, 1, 2, 3, 5, 10, 11, 21, 101, 1000000`. For count-conditioned units, the 1,000,000 sample is a CLDR `many` case in es/fr/pt-BR/it and maps to the plural surface. All strings preserve the original count value.

| Locale | 0 | 1 | 2 | 3 | 5 | 10 | 11 | 21 | 101 | 1000000 |
|---|---|---|---|---|---|---|---|---|---|---|
| ru | `0 мин` | `1 мин` | `2 мин` | `3 мин` | `5 мин` | `10 мин` | `11 мин` | `21 мин` | `101 мин` | `1000000 мин` |
| en | `0 min` | `1 min` | `2 min` | `3 min` | `5 min` | `10 min` | `11 min` | `21 min` | `101 min` | `1000000 min` |
| es | `0 min` | `1 min` | `2 min` | `3 min` | `5 min` | `10 min` | `11 min` | `21 min` | `101 min` | `1000000 min` |
| fr | `0 min` | `1 min` | `2 min` | `3 min` | `5 min` | `10 min` | `11 min` | `21 min` | `101 min` | `1000000 min` |
| pt-BR | `0 min` | `1 min` | `2 min` | `3 min` | `5 min` | `10 min` | `11 min` | `21 min` | `101 min` | `1000000 min` |
| de | `0 Min.` | `1 Min.` | `2 Min.` | `3 Min.` | `5 Min.` | `10 Min.` | `11 Min.` | `21 Min.` | `101 Min.` | `1000000 Min.` |
| it | `0 min` | `1 min` | `2 min` | `3 min` | `5 min` | `10 min` | `11 min` | `21 min` | `101 min` | `1000000 min` |

## Sample renders — `tracker.draft.5a09492140c306c89726`

Counts in order: `0, 1, 2, 3, 5, 10, 11, 21, 101, 1000000`. For count-conditioned units, the 1,000,000 sample is a CLDR `many` case in es/fr/pt-BR/it and maps to the plural surface. All strings preserve the original count value.

| Locale | 0 | 1 | 2 | 3 | 5 | 10 | 11 | 21 | 101 | 1000000 |
|---|---|---|---|---|---|---|---|---|---|---|
| ru | `$title: 0 минут` | `$title: 1 минута` | `$title: 2 минуты` | `$title: 3 минуты` | `$title: 5 минут` | `$title: 10 минут` | `$title: 11 минут` | `$title: 21 минута` | `$title: 101 минута` | `$title: 1000000 минут` |
| en | `$title: 0 min` | `$title: 1 min` | `$title: 2 min` | `$title: 3 min` | `$title: 5 min` | `$title: 10 min` | `$title: 11 min` | `$title: 21 min` | `$title: 101 min` | `$title: 1000000 min` |
| es | `$title: 0 minutos` | `$title: 1 minuto` | `$title: 2 minutos` | `$title: 3 minutos` | `$title: 5 minutos` | `$title: 10 minutos` | `$title: 11 minutos` | `$title: 21 minutos` | `$title: 101 minutos` | `$title: 1000000 minutos` |
| fr | `$title : 0 minute` | `$title : 1 minute` | `$title : 2 minutes` | `$title : 3 minutes` | `$title : 5 minutes` | `$title : 10 minutes` | `$title : 11 minutes` | `$title : 21 minutes` | `$title : 101 minutes` | `$title : 1000000 minutes` |
| pt-BR | `$title: 0 minuto` | `$title: 1 minuto` | `$title: 2 minutos` | `$title: 3 minutos` | `$title: 5 minutos` | `$title: 10 minutos` | `$title: 11 minutos` | `$title: 21 minutos` | `$title: 101 minutos` | `$title: 1000000 minutos` |
| de | `$title: 0 Minuten` | `$title: 1 Minute` | `$title: 2 Minuten` | `$title: 3 Minuten` | `$title: 5 Minuten` | `$title: 10 Minuten` | `$title: 11 Minuten` | `$title: 21 Minuten` | `$title: 101 Minuten` | `$title: 1000000 Minuten` |
| it | `$title: 0 minuti` | `$title: 1 minuto` | `$title: 2 minuti` | `$title: 3 minuti` | `$title: 5 minuti` | `$title: 10 minuti` | `$title: 11 minuti` | `$title: 21 minuti` | `$title: 101 minuti` | `$title: 1000000 minuti` |

## Sample renders — `tracker.draft.5ea449e59ed7e444a666`

Counts in order: `0, 1, 2, 3, 5, 10, 11, 21, 101, 1000000`. For count-conditioned units, the 1,000,000 sample is a CLDR `many` case in es/fr/pt-BR/it and maps to the plural surface. All strings preserve the original count value.

| Locale | 0 | 1 | 2 | 3 | 5 | 10 | 11 | 21 | 101 | 1000000 |
|---|---|---|---|---|---|---|---|---|---|---|
| ru | `Фокус: 0 мин работы` | `Фокус: 1 мин работы` | `Фокус: 2 мин работы` | `Фокус: 3 мин работы` | `Фокус: 5 мин работы` | `Фокус: 10 мин работы` | `Фокус: 11 мин работы` | `Фокус: 21 мин работы` | `Фокус: 101 мин работы` | `Фокус: 1000000 мин работы` |
| en | `Focus: 0 min of work` | `Focus: 1 min of work` | `Focus: 2 min of work` | `Focus: 3 min of work` | `Focus: 5 min of work` | `Focus: 10 min of work` | `Focus: 11 min of work` | `Focus: 21 min of work` | `Focus: 101 min of work` | `Focus: 1000000 min of work` |
| es | `Focus: 0 min de trabajo` | `Focus: 1 min de trabajo` | `Focus: 2 min de trabajo` | `Focus: 3 min de trabajo` | `Focus: 5 min de trabajo` | `Focus: 10 min de trabajo` | `Focus: 11 min de trabajo` | `Focus: 21 min de trabajo` | `Focus: 101 min de trabajo` | `Focus: 1000000 min de trabajo` |
| fr | `Focus : 0 min de travail` | `Focus : 1 min de travail` | `Focus : 2 min de travail` | `Focus : 3 min de travail` | `Focus : 5 min de travail` | `Focus : 10 min de travail` | `Focus : 11 min de travail` | `Focus : 21 min de travail` | `Focus : 101 min de travail` | `Focus : 1000000 min de travail` |
| pt-BR | `Focus: 0 min de trabalho` | `Focus: 1 min de trabalho` | `Focus: 2 min de trabalho` | `Focus: 3 min de trabalho` | `Focus: 5 min de trabalho` | `Focus: 10 min de trabalho` | `Focus: 11 min de trabalho` | `Focus: 21 min de trabalho` | `Focus: 101 min de trabalho` | `Focus: 1000000 min de trabalho` |
| de | `Focus: 0 Min. Arbeit` | `Focus: 1 Min. Arbeit` | `Focus: 2 Min. Arbeit` | `Focus: 3 Min. Arbeit` | `Focus: 5 Min. Arbeit` | `Focus: 10 Min. Arbeit` | `Focus: 11 Min. Arbeit` | `Focus: 21 Min. Arbeit` | `Focus: 101 Min. Arbeit` | `Focus: 1000000 Min. Arbeit` |
| it | `Focus: 0 min di lavoro` | `Focus: 1 min di lavoro` | `Focus: 2 min di lavoro` | `Focus: 3 min di lavoro` | `Focus: 5 min di lavoro` | `Focus: 10 min di lavoro` | `Focus: 11 min di lavoro` | `Focus: 21 min di lavoro` | `Focus: 101 min di lavoro` | `Focus: 1000000 min di lavoro` |

## Sample renders — `tracker.draft.43196b99adb515ba000e`

Counts in order: `0, 1, 2, 3, 5, 10, 11, 21, 101, 1000000`. For count-conditioned units, the 1,000,000 sample is a CLDR `many` case in es/fr/pt-BR/it and maps to the plural surface. All strings preserve the original count value.

| Locale | 0 | 1 | 2 | 3 | 5 | 10 | 11 | 21 | 101 | 1000000 |
|---|---|---|---|---|---|---|---|---|---|---|
| ru | `Ещё 0 областей: профессии и работа` | `Ещё 1 область: профессии и работа` | `Ещё 2 области: профессии и работа` | `Ещё 3 области: профессии и работа` | `Ещё 5 областей: профессии и работа` | `Ещё 10 областей: профессии и работа` | `Ещё 11 областей: профессии и работа` | `Ещё 21 область: профессии и работа` | `Ещё 101 область: профессии и работа` | `Ещё 1000000 областей: профессии и работа` |
| en | `0 more areas: professions and work` | `1 more area: professions and work` | `2 more areas: professions and work` | `3 more areas: professions and work` | `5 more areas: professions and work` | `10 more areas: professions and work` | `11 more areas: professions and work` | `21 more areas: professions and work` | `101 more areas: professions and work` | `1000000 more areas: professions and work` |
| es | `0 áreas más: profesiones y trabajo` | `1 área más: profesiones y trabajo` | `2 áreas más: profesiones y trabajo` | `3 áreas más: profesiones y trabajo` | `5 áreas más: profesiones y trabajo` | `10 áreas más: profesiones y trabajo` | `11 áreas más: profesiones y trabajo` | `21 áreas más: profesiones y trabajo` | `101 áreas más: profesiones y trabajo` | `1000000 áreas más: profesiones y trabajo` |
| fr | `0 domaine supplémentaire : professions et travail` | `1 domaine supplémentaire : professions et travail` | `2 domaines supplémentaires : professions et travail` | `3 domaines supplémentaires : professions et travail` | `5 domaines supplémentaires : professions et travail` | `10 domaines supplémentaires : professions et travail` | `11 domaines supplémentaires : professions et travail` | `21 domaines supplémentaires : professions et travail` | `101 domaines supplémentaires : professions et travail` | `1000000 domaines supplémentaires : professions et travail` |
| pt-BR | `Mais 0 área: profissões e trabalho` | `Mais 1 área: profissões e trabalho` | `Mais 2 áreas: profissões e trabalho` | `Mais 3 áreas: profissões e trabalho` | `Mais 5 áreas: profissões e trabalho` | `Mais 10 áreas: profissões e trabalho` | `Mais 11 áreas: profissões e trabalho` | `Mais 21 áreas: profissões e trabalho` | `Mais 101 áreas: profissões e trabalho` | `Mais 1000000 áreas: profissões e trabalho` |
| de | `Weitere 0 Bereiche: Berufe und Arbeit` | `1 weiterer Bereich: Berufe und Arbeit` | `Weitere 2 Bereiche: Berufe und Arbeit` | `Weitere 3 Bereiche: Berufe und Arbeit` | `Weitere 5 Bereiche: Berufe und Arbeit` | `Weitere 10 Bereiche: Berufe und Arbeit` | `Weitere 11 Bereiche: Berufe und Arbeit` | `Weitere 21 Bereiche: Berufe und Arbeit` | `Weitere 101 Bereiche: Berufe und Arbeit` | `Weitere 1000000 Bereiche: Berufe und Arbeit` |
| it | `Altre 0 aree: professioni e lavoro` | `1 altra area: professioni e lavoro` | `Altre 2 aree: professioni e lavoro` | `Altre 3 aree: professioni e lavoro` | `Altre 5 aree: professioni e lavoro` | `Altre 10 aree: professioni e lavoro` | `Altre 11 aree: professioni e lavoro` | `Altre 21 aree: professioni e lavoro` | `Altre 101 aree: professioni e lavoro` | `Altre 1000000 aree: professioni e lavoro` |

## Scope disposition

- `98eec670693ec0194f31` (`$minutes min`): no additional forms; abbreviation is fixed.
- `5ea449e59ed7e444a666` (Focus … `min` work): no additional forms; abbreviation is fixed.
- `5a09492140c306c89726`: plural surface forms for spoken-out minute nouns; English remains fixed `min`.
- `43196b99adb515ba000e`: count forms for the area noun in all seven locales.
- No source string, base translation, identifier, or user title is changed.

Supplement JSON SHA-256 (revision 2): `bf9beb4b91bb4d725ec1757310f7e0d82c10920ed25a6102a42d877a11aabaae`.
