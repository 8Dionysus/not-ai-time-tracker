# Tracker typed CSV issue resources: ar / zh-Hans / ja / ko / hi

Status: complete editorial draft for native-language and UI review. This is a static resource-data package, not a production-readiness claim or evidence of app support.

## Inputs and integrity

- Source catalog: `import-issue-resources-ru-en-es.json`
- Accepted source SHA-256: `6afb3475a1e63e39d5566f89ba005579636714fd8d9f5d54652baee6f062f9a3`
- Source review: `review-import-issue-resources.json`
- Review SHA-256: `d04566f434ee2eb3d715208431e53b8e11149ccc526f9edc6ebfa5e8d50d9f20`
- Output: `import-issue-resources-ar-zh-Hans-ja-ko-hi.json`
- Output SHA-256: `99a7b1da6eeb3c28d2fba19e55ca0b96e156842353e913867905f378d7577cad`
- Target locales: Arabic (`ar`, Modern Standard Arabic), Simplified Chinese (`zh-Hans`), Japanese (`ja`), Korean (`ko`), and Hindi (`hi`).

The source’s 64 `ImportIssueCode` entries are retained once each, in source order, with their exact `tracker.import.<lowercase enum>` keys. Each target locale has 64 nonempty main templates. The complete `CSV_SIZE_LIMIT` byte/UTF-16 branches and the two `LOCAL_TIME_GAP_OR_FOLD` gap/fold branches are present for all five target locales. All five locales have error- and warning-specific unknown-resource fallbacks.

Static data checks passed for exact enum/key coverage and order; all 64 × 5 main message slots; conditional branch coverage; exact placeholder-token multisets in main and conditional messages; and unchanged entry parameters, typed argument definitions, units, source references, severity, stages, context fields and field paths. Target UI templates do not translate identifiers, raw values, headers, IDs or diagnostic text. Original `en`, `ru`, and `es` content remains present. The Arabic strings contain no inserted invisible bidi controls.

## Semantics and renderer requirements

- Look up by the stable resource key/code. `diagnostic` and `CoreError.message` remain compatibility/logging data, never translated user-facing prose.
- Preserve `Text` exactly as supplied, including source headers, values, names, notes and invalid cells; escape only for safe display. Preserve each `Texts` item and order; localize only separators/quoting. Keep identifiers, namespaces, enum names and IDs unchanged.
- Keep typed `Count` magnitudes exact and display the declared unit. Do not round or reinterpret epoch-millisecond timestamps or duration milliseconds. `CSV_SIZE_LIMIT` must select exactly one producer branch: bytes, or early string length in UTF-16 code units. Do not label the UTF-16 threshold as bytes.
- `LOCAL_TIME_GAP_OR_FOLD`: `validOffsetCount=0` means nonexistent local time (DST gap); `2` means ambiguous local time (DST fold). The generic localized template remains for any other value.
- Row numbers are logical CSV record numbers: header = 1, first data record = 2; quoted multiline cells count as one record; blank records retain their positions. The displayed semantic field label is separate from the exact, untranslated source column header. Generated row `fieldPath` values remain machine/support context, not translated prose.
- A typed cause is optional. If supplied, show at most a separate reviewed generic explanation keyed by typed cause code/typed arguments. Never display its diagnostic prose.
- Render `errorIssues` and `warningIssues`, preserve total error count independently of pagination, and use `preview.canApply` as the sole domain accept/reject flag. Warnings alone do not invalidate the file. For unknown keys, use the locale- and severity-specific fallback while retaining the stable key in support/debug details.
- Arabic RTL: isolate dynamic LTR and mixed-direction values at render time with platform bidi-isolation facilities. This includes IDs, zone IDs, filenames, raw CSV content, numbers, timestamps, durations and user/catalog values. Handle layout direction and punctuation in the renderer. Do not insert invisible bidi controls into the localized strings or placeholder tokens. The same requirement is recorded in the JSON `resourceContract.rtlRenderingRequirement`.

## Editorial choices

- Variable counts use count labels / unit labels instead of English-style noun agreement wherever possible. Arabic byte and UTF-16 branches label the unit independently of the value; the other Arabic variable-count phrases use neutral count labels. Chinese uses natural measure/count constructions; Japanese and Korean use their normal non-inflecting count forms; Hindi uses count-label phrasing where needed. Numeric arguments remain exact and selectors are not inferred or added.
- Technical values, format tokens (`H:mm:ss`), protocol names, JSON/CSV spellings, namespaces and placeholders remain intact when they are contract data. Application/domain meaning and the source’s append-versus-replacement distinction are preserved.
- The copy retains the distinction between a CSV history append and a full JSON replacement/restore path; it does not imply that warnings alone reject an import or that an apply/rollback succeeded after verification failure.

## Scope and review

The locale extension remains confined to the new draft JSON and its notes. Independent review corrected only draft strings and locale-lineage metadata, and added renderer-safety lines to the separate CSV composition overlay; it did not modify the accepted RU/EN/ES source catalog, application/backend source, builds, Pages, or access settings. No application code, build, runtime test, or device QA was run. No application code, build, runtime test, or device QA was run. Native-language review and UI-fit/accessibility verification remain recommended before integration.


## Independent expanded-locale review corrections

The independent static/editorial review is recorded in `review-import-issue-expanded-locales.json`; its correction list contains exact old/new text and source provenance. The draft JSON now corrects row-order wording in all five Asian locales, “stable” versus “unique” namespace meaning in ja/ko, namespace scoping versus uniqueness in ja/ko, explicit excluded-interval count labels in zh-Hans/ja/ko, and Hindi “stopped session” wording that could be read as paused despite pauses being separately named. Arabic dynamic bidi isolation remains a renderer-time requirement; no invisible controls were added. Machine-readable lineage now points to the accepted base catalog/review and `coverage.translatedLocales` records 64 per target locale.

- Final output JSON SHA-256: `99a7b1da6eeb3c28d2fba19e55ca0b96e156842353e913867905f378d7577cad`
- Static result: 64/64 keys in source order; 64 nonempty messages in each of ar, zh-Hans, ja, ko, hi; both conditional groups complete; placeholder multisets and source fields match the accepted base.
