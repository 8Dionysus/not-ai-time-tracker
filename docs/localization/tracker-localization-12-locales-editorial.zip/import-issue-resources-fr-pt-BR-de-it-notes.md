# Tracker typed CSV import-issue catalog: fr, pt-BR, de, it

## Lineage and scope

- Translation base: `import-issue-resources-ru-en-es.json`, SHA-256 `6afb3475a1e63e39d5566f89ba005579636714fd8d9f5d54652baee6f062f9a3`.
- Base review: `review-import-issue-resources.json`, SHA-256 `d04566f434ee2eb3d715208431e53b8e11149ccc526f9edc6ebfa5e8d50d9f20`; status `passed_static_catalog_and_editorial_review_with_source_contract_corrections`.
- Backend source lineage remains final commit `0980c50954a201229c90008610328abd4369aa08` and source archive SHA-256 `2f8282c1a65a873c25a0feb3c9f0c2bdd65d8c6bc97e1bc61ff68df63ffa203c`.
- The derived catalog retains the accepted base locales and adds all 64 entries for fr, pt-BR, de and it. Source order, stable resource keys, code values, producer refs, enum refs, severity, stages, typed arguments, presence conditions, units, and context/field/cause contracts are copied unchanged. `UTF8_REQUIRED` is present; the enum count is 64.
- This is an editorial translation extension for frontend integration and locale review. It does not claim app integration or a reviewed production language pack.

## Renderer contracts retained

- Only resolve by the stable resource key/code. Diagnostic text and `CoreError.message` are not localized UI copy.
- `CSV_SIZE_LIMIT` has mutually exclusive byte-input (`actualBytes`) and early-string (`utf16Units`) templates. Each locale preserves the correct units for both the measured value and `maxBytes`.
- `LOCAL_TIME_GAP_OR_FOLD` keeps the generic message and the `validOffsetCount=0` nonexistent-time/gap and `=2` ambiguous-time/fold branches.
- Severity-specific unknown-resource fallbacks have been added for all four target locales; the stable unknown key remains available to support/debug views.
- Existing shared typed-value, row, field, machine-path, typed-cause, preview/pagination, and acceptance contracts remain unchanged. In particular, source Text and each Texts item pass through unchanged (only list separators/quoting are localized); identifiers, namespaces, enum values, raw values and source headers are not translated; Counts preserve exact magnitude/unit; dates use their typed renderer. The logical CSV record convention remains header=1, first data record=2, quoted multiline fields count once, blank records preserve positions. Field labels are distinct from original source headers; machine `fieldPath` is support context. A typed cause is optional and may only be rendered through its reviewed generic cause-code resource, never diagnostic prose. Preview uses `errorIssues`/`warningIssues`, keeps total error count independent of pagination, and `preview.canApply` remains the sole accept/reject flag; warnings alone do not invalidate the file.

## Placeholder and structural checks

- Static comparison against the accepted source covered 64 codes × 4 locales. Each new main message has the same placeholder set as the English source message; every new conditional branch has the same placeholders and branch identity as its source counterpart.
- Code order and code set, stable keys, source refs, typed arguments, conditions, context fields, and common renderer contracts are unchanged. The original RU/EN/ES content is retained as received; source file hash was verified before creating this extension.
- No application/runtime code, build, or device test was run.

## Plural-sensitive copy review

- Count-heavy text uses category labels or places the noun before the number (for example, total errors, number of candidate sessions, and excluded-interval count), so the interpolated numeral does not control a trailing noun/adjective ending.
- Bytes, milliseconds, and UTF-16 units are stated explicitly. Byte and code-unit branches avoid converting or rounding counts; `ms` remains an invariant unit marker. CSV record/count wording refers to logical records, not physical lines.
- Other measured counts (columns, records, error totals and sampled records) remain exact numeric values. Lists (`columns`, `delimiters`) retain the source items and order; only separators/quoting are locale-specific.


## Independent expanded-locale review corrections

The independent static/editorial review is recorded in `review-import-issue-expanded-locales.json`; its correction list contains exact old/new text and source provenance. All four ROW_FINGERPRINT_DEDUPE translations now explicitly say the order of rows within the file can change; exact row fingerprints dedupe replay imports, while changed rows require review and may overlap. The renderer also requires separately severity-marked error/warning groups and Arabic bidi isolation where these locale packs are composed into the outer CSV dialog.

- Final output JSON SHA-256: `cac849b60e91285ebb8ba2284a6e034ba6426140d4ee24b63807317a319c2cde`
- Static result: 64/64 keys in source order; 64 nonempty messages in each of fr, pt-BR, de, it; both conditional groups complete; placeholder multisets and source fields match the accepted base.
