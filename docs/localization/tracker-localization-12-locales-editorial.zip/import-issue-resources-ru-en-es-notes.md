# Tracker typed CSV localization resource notes

- Source: final commit `0980c50954a201229c90008610328abd4369aa08`; archive SHA-256 `2f8282c1a65a873c25a0feb3c9f0c2bdd65d8c6bc97e1bc61ff68df63ffa203c`.
- Enum declaration: `core/src/main/kotlin/dev/notai/tracker/ImportIssues.kt:8`. Producer source references and target-side patch line numbers are attached to every catalog entry.
- Reconciliation: task/report called this a 63-code enum; independent counting of the supplied enum declaration gives 64 distinct values. The 64-entry catalog is complete for this source, including `INSPECTION_FAILED` as code 64.
- Full RU/EN/ES resource entries, source refs, typed arguments, fields/field paths, severity/stages, and message variants are in the adjacent JSON. These are draft translations for frontend integration/review; the backend explicitly says no reviewed translation packs are supplied.

## Conditional renderer contract

- Resolve only by `tracker.import.<lowercase enum name>` / enum code. Never inspect old English diagnostic text or show `diagnostic` / `CoreError.message` as translated UI prose.
- `CSV_SIZE_LIMIT`: select the branch by presence of `actualBytes` versus `utf16Units`; display the corresponding units. `maxBytes` comes from the common limit constant, but the early string guard counts UTF-16 code units.
- `LOCAL_TIME_GAP_OR_FOLD`: `validOffsetCount=0` means nonexistent local time (DST gap); `2` means ambiguous local time (DST fold).
- Preserve source Text, Texts list contents, IDs/Identifiers, namespace, headers, names, notes, raw invalid cells, provenance and archive data unchanged. Escape only for safe UI display. Use Count's exact unit; do not round epoch-millisecond timestamps or duration milliseconds.
- Row numbers refer to logical CSV records: header 1, first data record 2; quoted multiline values count once and blank records keep their positions. The exact source header is not the translated semantic field label.
- Render a typed `cause` only through a reviewed generic domain resource keyed by typed cause code and typed args, never by diagnostic prose. A cause can be absent even when the outer CoreError has a code.
- Preview must render `errorIssues` / `warningIssues`, preserve total error count independent of pagination, and continue using `preview.canApply` as the only domain accept/reject flag. Warnings alone do not invalidate a file. Unknown resources use severity-specific localized fallback and retain the stable key for support.
