# Independent Arabic and Simplified Chinese composition review

Date: 2026-10-15
Status: passed static editorial review; integration remains pending.

## Scope and result

Independently reviewed all 48 ready composition units and 101 source occurrences in Arabic and Simplified Chinese, including every translated user-facing branch, typed placeholder, error/status distinction, and all five contextual semantic notes. No translation was changed. The one CSV import-preview composition unit remains blocked in both locales, with its two source occurrences retained and no partial copy proposed because its nested dynamic errors and warnings lack stable typed localization contracts.

No semantic translation defects or source-integrity defects were found. Every per-key review note and exact occurrence assignment is recorded in `review-ar-zh-composition.json`.

## Focused checks

- Source SHA-256 bindings were recomputed for the manifest, composition resolution, correction overlay, semantic-context file, both target packages and corresponding notes. All embedded bindings match. Source Russian objects, baseline recipes, occurrence IDs, and both full overlay correction records match their canonical sources exactly.
- Coverage is exact: 48 ready units / 101 occurrence IDs per locale; one blocked key / two IDs: `tracker.draft.d7bacc8fa4bed5ab16cb`, `UI-9eb89e6c-cf8364-L0279-C025`, `UI-9eb89e6c-cf8364-L0279-C210`. No extra or missing IDs.
- The restore preview has all four Boolean combinations. `segments` maps to `preview.segments`; the consequence slot appears once; each combination selects one slot value, and both-true uses one combined unknown-time warning rather than concatenating the two single-flag variants.
- Both technical panels use ` · Room {roomSchemaVersion}` only when exact-final-build Room metadata has been verified; otherwise the suffix is empty. No translated output hardcodes Room 5, Room 6, or JSON 8.
- All 12 Arabic counted-noun argument objects have `zero`, `one`, `two`, `few`, `many`, and `other`. Selector results match the integer vector 0→zero, 1→one, 2→two, 3→few, 10→few, 11→many, 99→many, 100→other, 102→other. Source count expressions and one/two selector guards were checked.
- Stable source error keys/codes remain exact in each copied source recipe; user-facing error-code placeholders stay intact, and no raw exception prose was added. Arabic contains no hidden bidi controls.
- Semantic-context entries are outside these ready composition keys; the blocked CSV’s import-into-app distinction is not used to invent a translation for its unsafe dynamic nested payload.

## Hashes

- `translation-units.json`: `285e196dac220a2d3e95ffed48034bc04713d7e29995d8b8aedf7cb3e4cf6324`
- `composition-resolution.json`: `af2648725aeab5817ab872a058149dcd55954e179db25c6e40d9a2e59616cfab`
- `composition-correction-overlay.json`: `6aee8e082c14f079d2b6e83de231bbbc92e6a096724deed10894ccf962b1a240`
- `translation-semantic-context.json`: `cf35e1042130b9c228f687427df14a9bb110a7fe0359000a7e6e74c75a1ee72b`
- `translations-ar-composition.json`: `333ac3ff55ac071264e0a51f1351c234d7d2e190d9e25e30dbaf7ac30bf00ff7`
- `translations-zh-Hans-composition.json`: `c6eeb9f2a7cc9aa60bec7d7f93f5769bedbd4a543ab1a78373c5f51a440a5a04`
- `review-ar-zh-composition.json`: `6599c84f8ab7797283c75640d2245a1533a5b62eaf6cd830ce7321f1165cc7a4`

No build, app code, runtime, device QA, or application test was run.
