# Expanded import-issue locale and composition review

Date: 2026-10-15
Review JSON: `review-import-issue-expanded-locales.json` (exact old/new/provenance for each reviewer correction is recorded there).

## Readiness

- Editorial ready: yes, after the documented small copy/metadata/renderer-contract corrections.
- Production/localization pack claim: no; native-language signoff remains recommended.
- UI integration: pending. Resource registration, typed renderer wiring, severity-separated display, source value safety, Arabic runtime bidi isolation, and accessibility/device acceptance remain frontend work.
- RU/EN/ES base received the prior independent review and was not re-reviewed here; all three base messages and source contracts were machine-compared unchanged against both extensions.

## Hashes (SHA-256)

- `import-issue-resources-ru-en-es.json`: `6afb3475a1e63e39d5566f89ba005579636714fd8d9f5d54652baee6f062f9a3`
- `review-import-issue-resources.json`: `d04566f434ee2eb3d715208431e53b8e11149ccc526f9edc6ebfa5e8d50d9f20`
- `review-import-issue-resources-notes.md`: `9fdcc13e4e7840e610fe7b28d867715bec154680ebfcbfb02d719913ab94926f`
- `import-issue-resources-fr-pt-BR-de-it.json`: `cac849b60e91285ebb8ba2284a6e034ba6426140d4ee24b63807317a319c2cde`
- `import-issue-resources-fr-pt-BR-de-it-notes.md`: `1caabb3e22f1bbcdf3792a2097f7d065c83559a312ff9450a389dbc624de2442`
- `import-issue-resources-ar-zh-Hans-ja-ko-hi.json`: `99a7b1da6eeb3c28d2fba19e55ca0b96e156842353e913867905f378d7577cad`
- `import-issue-resources-ar-zh-Hans-ja-ko-hi-notes.md`: `2792bd415fd208b6c1f564cca1447cb43854fc0d111de7cad6308f4e9add8600`
- `csv-composition-resolution-overlay.json`: `93522eb77245e6c5ebfc295e41257901c7c9ece3fac857cfbaba1e5a692fa9b3`
- `backend.patch`: `9007c823fbecfc62c311304b764be0f0dfb0d8d320ecdec5bce3213a881054be`
- `IMPORT_ISSUES.md`: `c67e6772c8ee63a12c1c2277652e2ad5e3b66c2924f5565fd6d11fe42d9cfb94`
- `OPUS_IMPORT_INTEGRATION.md`: `54b1cec6e891cac0eb59e2faf91f6915abf7ed208c3c344c1b72b7bbb084ce73`

## Coverage

The source enum was parsed from `backend.patch` and contains 64 codes. `UTF8_REQUIRED` is included; it contains a digit, so an A–Z-only pattern incorrectly yields 63. Each of these twelve locales has exactly 64 messages: ru, en, es, fr, pt-BR, de, it, ar, zh-Hans, ja, ko, hi. Both extension JSONs have 64 codes in source order, 64 exact stable keys, no duplicate codes, and 64 nonempty entries per target locale. The full review JSON has machine-readable locale-by-locale counts and the 64-key source-order list.

All target locales include both `CSV_SIZE_LIMIT` branches (bytes vs UTF-16 code units) and both `LOCAL_TIME_GAP_OR_FOLD` branches (0 gap vs 2 fold) plus the generic variant. Every translated main/conditional placeholder matches its source template; placeholders are declared by typed arguments. Shared source fields, stages, conditional optional arguments, units, `rowNumber`/column/field context, machine `fieldPath`, apply cause arguments/fieldPath pass-through, severity and resource keys match the accepted base. Diagnostics remain compatibility/logging text; renderer uses stable keys and typed arguments.

Full 64-code coverage in source order:

- CSV_SIZE_LIMIT, CSV_EMPTY, CSV_HEADER_INVALID, CSV_COLUMNS_MISSING, SOURCE_NAMESPACE_REQUIRED, CLOCK_TOLERANCE_UNSUPPORTED, END_OR_DURATION_REQUIRED, SOURCE_ZONE_INVALID
- TIMESTAMP_PATTERN_INVALID, CSV_DELIMITER_INVALID, CSV_COLUMN_LIMIT, CSV_ROW_LIMIT, CSV_QUOTING_INVALID, CSV_QUOTE_UNCLOSED, ROW_COLUMN_COUNT, TIMESTAMP_INVALID
- LOCAL_TIME_GAP_OR_FOLD, SUBMILLISECOND_PRECISION, TIMESTAMP_RANGE, INTERVAL_INVALID, INTERVAL_OVERFLOW, DURATION_ENDPOINT_MISMATCH, SOURCE_ID_MISSING, DURATION_HMS_REQUIRED
- DURATION_COMPONENT_RANGE, DURATION_NUMBER_INVALID, DURATION_PRECISION_OR_RANGE, DURATION_POSITIVE_REQUIRED, ROW_PARSE_FAILED, SOURCE_ID_CONFLICT, FUTURE_INTERVAL, MAPPING_REQUIRED
- MAPPING_INVALID, BATCH_VALIDATION_FAILED, PREVIEW_HAS_ERRORS, ROLLBACK_VERIFICATION_FAILED, APPLY_STALE, APPLY_STORAGE_FAILED, APPLY_FAILED, PROVENANCE_COLUMNS_RETAINED
- CLOCK_TOLERANCE_DECLARED, ROW_FINGERPRINT_DEDUPE, SOURCE_ID_NAMESPACE, EXPLICIT_OFFSET_REQUIRED, LOCAL_ZONE_DST_REJECTED, INTERVALS_EXCLUDED, SESSION_GROUPING_LOSS, CONTEXT_REQUIRES_MAPPING
- EXACT_CSV_FORMULA_POLICY, UTF8_REQUIRED, BACKUP_UNSUPPORTED, BINARY_UNSUPPORTED, NO_CONSISTENT_TABLE, REPLACEMENT_REQUIRES_PREVIEW, MAPPING_CONFIRMATION_REQUIRED, INSPECTION_SAMPLE_LIMIT
- TIME_CHOICE_REQUIRED, MULTIPLE_DELIMITERS, SAMPLED_DELIMITER, DELIMITED_TEXT_REQUIRED, DELIMITER_NOT_INSPECTED, DURATION_FORMAT_REQUIRED, SOURCE_ZONE_REQUIRED, INSPECTION_FAILED

## Semantic review and corrections

Count labels and units are plural-safe; measured magnitudes are preserved. Byte and UTF-16 paths are mutually exclusive; epoch millisecond values remain exact; local-time gap/fold meanings are distinguished. Rollback messages consistently describe snapshot verification before mutation and confirm no imported records were written. Arabic strings contain no invisible directional controls; bidi isolation is renderer-time only.

The review found and corrected these issues: row fingerprint wording in all nine added locales was ambiguous about row order vs column/file order; Japanese/Korean namespace text changed `stable` into `unique` and claimed uniqueness where source promises only scoping; Simplified Chinese/Japanese/Korean excluded-interval text did not clearly label the placeholder as a count; Hindi “stopped session” could read as paused despite pauses being separately named. Exact old/new strings and source lines are recorded in the JSON correction array.

The new CSV composition overlay was independently checked in all 12 languages. Its exact previous blocked resolution remains embedded unchanged. The replacement data contract uses `preview.errorIssues` and `preview.warningIssues`, takes first 30 typed errors while preserving total count and list order, reports the backend's `preview.canApply` as the only acceptance flag, never parses raw diagnostics, has a legacy missing-issues fallback, and preserves append-history vs full JSON restore distinction. Error and warning groups must remain visibly distinct; Arabic dynamic values require runtime bidi isolation.

No application/backend source, frozen composition artifacts, Pages, or access settings were edited; no app/runtime code, builds, or device tests were run.
