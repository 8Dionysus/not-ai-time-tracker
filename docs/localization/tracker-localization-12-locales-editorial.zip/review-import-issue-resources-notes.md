# Independent typed CSV import-resource review

Date: 2026-10-15
Status: static review passed with catalog-only contract and copy corrections; app integration remains pending.

## Scope and outcome

Reviewed `import-issue-resources-ru-en-es.json` against the final backend patch and both import issue handoff documents. The enum is **64**, not 63: the source contains `UTF8_REQUIRED`, whose digit is why an `[A-Z_]`-only enum regex falsely counts 63. All 64 enum codes appear exactly once, in source order, with exact `tracker.import.<lowercase enum name>` keys, 67 producer references matching reconstructed target-side patch lines, and 64 nonempty entries for each of EN/RU/ES. All language templates retain matching placeholder sets; the byte-vs-UTF-16 conditional branches are complete.

The catalog-only draft was corrected. Four parser issue entries now include `INSPECTION` as well as `PARSE`, because explicit inspection can surface those parser failures at inspection stage. `APPLY_STALE`, `APPLY_STORAGE_FAILED`, and `APPLY_FAILED` now describe dynamic typed cause-argument and fieldPath forwarding; generated logical-row field paths are specified. The rollback message now says snapshot verification failed before imported records were written. The timestamp parse message no longer attributes arbitrary parse failure to the zone. Count-bearing strings and three Russian phrases were edited for exact meaning and grammar; all exact old/new text, source locations, and change history are in `review-import-issue-resources.json`.

Diagnostic strings remain compatibility/logging data, never localized UI prose. Texts lists, IDs/identifiers, names, namespaces, headers and raw invalid values are preserved. Row numbering remains logical CSV record numbering (header 1, first data record 2; quoted multiline one record; blank records preserve positions). The typed `cause` is optional and is rendered only via a reviewed typed cause resource. Preview UI must use `errorIssues`/`warningIssues`, retain total errors independently of pagination, and treat `preview.canApply` as the sole accept/reject flag; warnings alone do not invalidate a file.

## Full source-enum coverage

`CSV_SIZE_LIMIT, CSV_EMPTY, CSV_HEADER_INVALID, CSV_COLUMNS_MISSING, SOURCE_NAMESPACE_REQUIRED, CLOCK_TOLERANCE_UNSUPPORTED, END_OR_DURATION_REQUIRED, SOURCE_ZONE_INVALID, TIMESTAMP_PATTERN_INVALID, CSV_DELIMITER_INVALID, CSV_COLUMN_LIMIT, CSV_ROW_LIMIT, CSV_QUOTING_INVALID, CSV_QUOTE_UNCLOSED, ROW_COLUMN_COUNT, TIMESTAMP_INVALID, LOCAL_TIME_GAP_OR_FOLD, SUBMILLISECOND_PRECISION, TIMESTAMP_RANGE, INTERVAL_INVALID, INTERVAL_OVERFLOW, DURATION_ENDPOINT_MISMATCH, SOURCE_ID_MISSING, DURATION_HMS_REQUIRED, DURATION_COMPONENT_RANGE, DURATION_NUMBER_INVALID, DURATION_PRECISION_OR_RANGE, DURATION_POSITIVE_REQUIRED, ROW_PARSE_FAILED, SOURCE_ID_CONFLICT, FUTURE_INTERVAL, MAPPING_REQUIRED, MAPPING_INVALID, BATCH_VALIDATION_FAILED, PREVIEW_HAS_ERRORS, ROLLBACK_VERIFICATION_FAILED, APPLY_STALE, APPLY_STORAGE_FAILED, APPLY_FAILED, PROVENANCE_COLUMNS_RETAINED, CLOCK_TOLERANCE_DECLARED, ROW_FINGERPRINT_DEDUPE, SOURCE_ID_NAMESPACE, EXPLICIT_OFFSET_REQUIRED, LOCAL_ZONE_DST_REJECTED, INTERVALS_EXCLUDED, SESSION_GROUPING_LOSS, CONTEXT_REQUIRES_MAPPING, EXACT_CSV_FORMULA_POLICY, UTF8_REQUIRED, BACKUP_UNSUPPORTED, BINARY_UNSUPPORTED, NO_CONSISTENT_TABLE, REPLACEMENT_REQUIRES_PREVIEW, MAPPING_CONFIRMATION_REQUIRED, INSPECTION_SAMPLE_LIMIT, TIME_CHOICE_REQUIRED, MULTIPLE_DELIMITERS, SAMPLED_DELIMITER, DELIMITED_TEXT_REQUIRED, DELIMITER_NOT_INSPECTED, DURATION_FORMAT_REQUIRED, SOURCE_ZONE_REQUIRED, INSPECTION_FAILED

## Source and artifact hashes

- Reviewed catalog after corrections: `6afb3475a1e63e39d5566f89ba005579636714fd8d9f5d54652baee6f062f9a3`
- Backend patch: `9007c823fbecfc62c311304b764be0f0dfb0d8d320ecdec5bce3213a881054be`
- `evidence/IMPORT_ISSUES.md`: `c67e6772c8ee63a12c1c2277652e2ad5e3b66c2924f5565fd6d11fe42d9cfb94`
- `evidence/OPUS_IMPORT_INTEGRATION.md`: `54b1cec6e891cac0eb59e2faf91f6915abf7ed208c3c344c1b72b7bbb084ce73`
- Source archive zip: `2f8282c1a65a873c25a0feb3c9f0c2bdd65d8c6bc97e1bc61ff68df63ffa203c`
- Backend bundle: `9114da98cdc44b5a702ab3bd7d2f132010b58da14e71a92e5c19821ecd6fb441`
- Existing catalog handoff notes reviewed: `bc50348624f3152477606b4308aa4d2f3f9980291e4ff8995123e51bb1a26386`

The pre-edit catalog hash was not recorded before the authorized in-place corrections; no pre-edit hash is claimed. The review JSON carries the exact before/after correction text and source provenance. No backend application code, manifest, Pages, build, or runtime test was changed or run.
