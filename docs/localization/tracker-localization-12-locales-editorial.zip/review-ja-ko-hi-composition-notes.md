# Independent composition review — Japanese, Korean, Hindi

Date: 2026-10-15
Status: 48/48 ready composition recipes reviewed semantically in each of ja, ko, and hi-IN (144 locale-unit reviews; 303 ready source occurrences counted per locale). Eleven small source-confirmed editorial fixes are included in the target composition JSONs. All files remain editorial drafts pending integration.

## Inputs and outputs

| File | SHA-256 |
|---|---|
| `translation-units.json` | `285e196dac220a2d3e95ffed48034bc04713d7e29995d8b8aedf7cb3e4cf6324` |
| `composition-resolution.json` | `af2648725aeab5817ab872a058149dcd55954e179db25c6e40d9a2e59616cfab` |
| `composition-correction-overlay.json` | `6aee8e082c14f079d2b6e83de231bbbc92e6a096724deed10894ccf962b1a240` |
| `translation-semantic-context.json` | `cf35e1042130b9c228f687427df14a9bb110a7fe0359000a7e6e74c75a1ee72b` |
| Accepted base `translations-ja.json` | `7202dc244527134300b1459c52cef42dba780df1e98bad41fa27681b4f0c452f` |
| Accepted base `translations-ko.json` | `66422a760c5c8fe9e341c4b7414ab69c736ab57b7c3c8bf2ea01fb93ee8801c2` |
| Accepted base `translations-hi.json` | `8d5ad7320e91cf4a56f35bc6c1dd4d489dd2775be071f18603d378fb933c3370` |
| `translations-ja-composition.json` | `f1d754838b5b6a5642ce576ac1c8003f1866f8f277fcac9433ac42adcef51d3a` |
| `translations-ko-composition.json` | `e197d262c81d1b9a23e794e25d456e94bc55926a85015d2ff672e1e8e903adeb` |
| `translations-hi-composition.json` | `6da12fa497d6d51ba53abc7cdefffcbfea80b410abc263ce9af26b6c14e2a373` |
| `review-ja-ko-hi-composition.json` | `6b5ccde5145aaaa7c457cee72ea596e64b7a3261448bc263789c93857f16185f` |

Accepted base package hashes were rechecked and remain unchanged. The JSON review includes source and accepted-base note hashes, exact review scope and keys, editorial findings with old/new text and provenance, contract checks, and remaining blockers.

## Review result

- Exact source composition coverage: 49 keys / 103 occurrence IDs; 48 ready recipes / 101 translated IDs and one blocked CSV recipe / 2 untranslated IDs in each locale. Every ID occurs exactly once; the blocked recipe has no partial translation.
- For all 49 keys, copied Russian source, resolved recipe, conditions, typed arguments, source evidence and status match the resolution package exactly. Stable error keys/codes and per-record hashes are preserved. The two correction-overlay contracts, prior values, evidence and rebase status remain attached and unchanged.
- All target enum/branch arrays were compared with their source contracts. Existing package validation reports 46 uncorrected placeholder comparisons plus two corrected-overlay placeholder/branch checks per locale. Raw exception class/message payloads were not added to UI strings.
- Checked all four `unfinishedTail`/`unfinishedFocus` combinations, one `{consequence}` slot, one combined both-true warning with both unknown times, and `segments ← preview.segments`. Session, segment, card and goal counts remain distinct. Room version is shown only through a verified metadata suffix and omitted when unverified; no fixed Room 5/6 or JSON 8 is asserted.
- Full per-key findings and exact changed strings are in `review-ja-ko-hi-composition.json` and the locale-specific composition notes. Changes: ja 7; ko 3; hi-IN 1.

## Remaining before integration/release

- `tracker.draft.d7bacc8fa4bed5ab16cb`: CSV preview remains blocked until row-summary, error and warning payloads have a complete translator-safe contract; retain both IDs untranslated.
- Rebase restore-preview and Room contracts to the exact final Sol SHA. Verify Room schema version from that target build’s `@Database`/generated metadata; never infer it from a JSON backup version.
- `tracker.draft.db5dc196ba061092492b`: map known `CoreError`/`ErrorCode` values in `{errorCode}` to localized enum labels, or keep technical codes diagnostic-only; never render raw `e.code`.
- Resolve source-copy claim `tracker.draft.5027e9837e3ca3339a41` jointly across locales: “all data only on this phone” conflicts with explicit user-selected external/cloud exports.
- Native linguistic/UI-fit, accessibility/layout, build/runtime and device-locale QA remain outstanding. This static review does not establish that the app has runtime localization.

No source code, app, or Pages were changed; no build, runtime, or device test was run.
