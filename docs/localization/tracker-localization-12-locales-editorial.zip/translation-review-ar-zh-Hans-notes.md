# Arabic and Simplified Chinese Tracker translation review

- Source manifest SHA-256: `285e196dac220a2d3e95ffed48034bc04713d7e29995d8b8aedf7cb3e4cf6324` (independently matched).
- Scope: all 376 ready units and all 402 variants in each locale, including 25 conditional units / 51 conditional variants; no sampling.
- Static joins passed for exact key order, source text, conditions, source occurrence IDs, source-text hashes, typed placeholder metadata and placeholder multisets. Across both outputs, 437 ready occurrence IDs and 126 remainder IDs cover all 563 manifest IDs exactly once. The remainder has 49 `needs_composition` and 5 `non_translatable` units. The Chinese remainder retains keys, status, source text and IDs but is a compact projection, omitting some additional source-context metadata.
- `zh-Hans` is explicitly Simplified Chinese only; `zh-Hant` is not included. No app build, runtime, notification, or device QA was performed.
- Undo ambiguity was resolved correctly in both translations: `تم التراجع` / `已撤销` means the prior action was undone, not that a pending operation was cancelled.
- Restore/full replacement, unknown-time, count/time, CSV import-vs-report, and backup/export distinctions were read through the full slice. Specific suggested edits with exact current strings and reasons are in the JSON.
- Arabic strings contain no bidi control characters. Keep dynamic IDs, brand strings, times, format labels and mixed LTR text isolated at the RTL presentation layer; do not inject bidi marks into stored translation data.

## Highest-priority editorial edits

- Clarify that cancelled export leaves its prepared files retained (`tracker.draft.03403303899776be344a`).
- State that CSV append adds imported records to the app, not to a CSV file (`tracker.draft.83d281e880bb242dcc0f`).
- Clarify the picker’s `PickMode.LABEL` action (`tracker.draft.b9be2dbbb401ad65b3f2`). The JSON enumerates all four Arabic direct count+noun gaps and their integer arguments: `$minutes` (`tracker.draft.98eec670693ec0194f31`, `tracker.draft.5a09492140c306c89726`), `home?.focusMinutes ?: 25` (`tracker.draft.5ea449e59ed7e444a666`), and `d.moreAreas.size` (`tracker.draft.43196b99adb515ba000e`), with Arabic one/two/few/many forms noted.
- Make the Arabic restore-preview wording explicit that DB/WAL/SHM hash values were verified before replacement (`tracker.draft.c7136c476a6c9346b839`).
- Translate the Chinese technical time-zone `offset` hint as `时区偏移量` (`tracker.draft.2a2b9066a0db5a90aa35`).

Full per-key findings, exact current/suggested text, structural validation details and context are in `translation-review-ar-zh-Hans.json`. Translation files were not changed.
