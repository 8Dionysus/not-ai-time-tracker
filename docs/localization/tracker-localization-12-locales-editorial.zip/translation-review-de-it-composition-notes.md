# DE/IT composition translation review

Date: 2026-10-15

## Result

Full static semantic and structural review completed for both supplements. The translated strings pass the reviewed recipe, enum, branch, plural-language and safety semantics. Four nonblocking structural coverage/provenance findings were corrected with reversible metadata-only updates and are now closed. No translation text, source record, overlay, or app/runtime file was changed.

## Inputs and coverage

- `composition-resolution.json`: SHA-256 `af2648725aeab5817ab872a058149dcd55954e179db25c6e40d9a2e59616cfab`
- Required `composition-correction-overlay.json`: SHA-256 `6aee8e082c14f079d2b6e83de231bbbc92e6a096724deed10894ccf962b1a240` (matches required hash)
- `translation-semantic-context.json`: SHA-256 `cf35e1042130b9c228f687427df14a9bb110a7fe0359000a7e6e74c75a1ee72b`; all 5 entries read
- `translations-de-composition.json` after structural closure: SHA-256 `dc7d114a5dae90b57ac9bcc5b814d6d6221679de38e1a1475da9c1400f07b3e7`
- `translations-it-composition.json` after structural closure: SHA-256 `5a0dc72f3a22e2b48a55a31c70a239073a283b5880c5150a141ea8d430fc3ac2`
- German: 48 translated ready units / 101 occurrences; one blocked CSV unit / 2 occurrences. All 49 keys and 103 occurrence IDs are covered exactly once when the separate blocked record is included.
- Italian: 48 translated ready units / 101 occurrences; one blocked CSV unit / 2 occurrences. All 49 keys and 103 occurrence IDs are covered exactly once.
- The CSV unit `tracker.draft.d7bacc8fa4bed5ab16cb` remains blocked in both supplements; neither has a partial translation.

## Review checks

- For every ready record in both locales, the immutable Russian source, original resolved recipe, occurrence IDs, source evidence and typed argument contracts were compared against the resolution. The mandatory overlay is applied only as a separate proposed target composition for its two designated keys; old source and recipe values remain distinct.
- The later fifth semantic-context entry about export cancellation was re-read; its key is outside the 49 composition units. The DE/IT export-preparation failure strings do not claim completed destination writes or preserved private output files. All six stable error keys and both full `INVALID_INPUT` codes were checked against the source recipes and remain byte-for-byte exact; no shortened target codes were found.
- Direct branch selector sequences were checked across all translated units (60 each; no mismatch). Every enum, conditional branch, plural form, placeholder reference and formatted-value contract was reviewed. No target placeholder names lacked a declared source/derived slot.
- Restore preview uses `{segments}` ← `preview.segments`; `unfinishedTail`/`unfinishedFocus` yield 0/1/1/1 warning sentences, with one combined sentence for both true flags.
- Focus WORK/BREAK outputs are separate, natural labels in each language, so no fixed gender agreement is imposed on a dynamic phase.
- The undo wording is post-action reversal (DE `rückgängig machen`; IT `annullare l’eliminazione subito dopo`), not cancellation of a pending operation.
- Backup-history fallbacks state that no backups have been created for/from the device yet. They do not claim the phone physically contains no backup file.
- The Room suffix is optional and constrained to SHA-verified exact-final-build Room metadata; no fixed Room/JSON version is proposed.

## Findings

### DE-COV-PLURAL-01 (DE, low)

Current: `{"per_unit_claimed_plural_output_forms":{"tracker.draft.732c387a55591a641041":{"current":0,"suggested":4},"tracker.draft.c8c6f09530d96b112f5c":{"current":36,"suggested":2},"tracker.draft.8b4e4ed2b5d4ff15bfbc":{"current":36,"suggested":2},"tracker.draft.52c08c717c95f8409a5e":{"current":0,"suggested":2},"tracker.draft.74f8fef1fa7615aefbe3":{"current":0,"suggested":2}},"locale_recorded_total":84,"materialized_total":24}`

Suggested: `{"per_unit_plural_output_forms":{"tracker.draft.732c387a55591a641041":4,"tracker.draft.eefe53ffeb7ba59a31b9":6,"tracker.draft.c8c6f09530d96b112f5c":2,"tracker.draft.21e8761d3cd7c48a7965":6,"tracker.draft.8b4e4ed2b5d4ff15bfbc":2,"tracker.draft.52c08c717c95f8409a5e":2,"tracker.draft.74f8fef1fa7615aefbe3":2},"locale_total":24}`

Reason: The field is named plural_output_forms, but its per-unit values do not equal the number of translated one/other strings materialized in the adjacent plural_forms maps. This is a coverage-metadata error; the actual German/Italian plural translations and CLDR categories are intact.

Translation text change required: no

Status after structural closure: closed. The DE counters now equal the translated one/other map leaves (24 total); the old/new values are preserved in the DE supplement correction history.

### IT-COV-PLURAL-01 (IT, low)

Current: `{"per_unit_claimed_plural_output_forms":{"tracker.draft.eefe53ffeb7ba59a31b9":{"current":9,"suggested":6},"tracker.draft.c8c6f09530d96b112f5c":{"current":3,"suggested":2},"tracker.draft.21e8761d3cd7c48a7965":{"current":9,"suggested":6},"tracker.draft.8b4e4ed2b5d4ff15bfbc":{"current":3,"suggested":2},"tracker.draft.52c08c717c95f8409a5e":{"current":0,"suggested":2},"tracker.draft.74f8fef1fa7615aefbe3":{"current":0,"suggested":2}},"locale_recorded_total":28,"materialized_total":24}`

Suggested: `{"per_unit_plural_output_forms":{"tracker.draft.732c387a55591a641041":4,"tracker.draft.eefe53ffeb7ba59a31b9":6,"tracker.draft.c8c6f09530d96b112f5c":2,"tracker.draft.21e8761d3cd7c48a7965":6,"tracker.draft.8b4e4ed2b5d4ff15bfbc":2,"tracker.draft.52c08c717c95f8409a5e":2,"tracker.draft.74f8fef1fa7615aefbe3":2},"locale_total":24}`

Reason: The field is named plural_output_forms, but its per-unit values do not equal the number of translated one/other strings materialized in the adjacent plural_forms maps. This is a coverage-metadata error; the actual German/Italian plural translations and CLDR categories are intact.

Translation text change required: no

Status after structural closure: closed. The IT counters now equal the translated one/other map leaves (24 total); the old/new values are preserved in the IT supplement correction history.

### DE-PROV-EDITORIAL-NOTES-01 (DE, low)

Current: `{"field":"editorial_notes_exact","present_for_nonempty_source_notes":false,"source_notes":{"tracker.draft.eefe53ffeb7ba59a31b9":[{"kind":"independent_ru_copyedit_note","source_form_preserved_exactly":{"one":"своё занятие","few":"своих занятия","many":"своих занятий"},"note":"Root reviewer explicitly flagged “своих занятия” for editorial review. This artifact preserves the source forms verbatim. Do not silently change; ask a Russian copy editor to confirm whether “свои занятия” or another phrasing is preferred while retaining the correct counted-noun morphology."}],"tracker.draft.21e8761d3cd7c48a7965":[{"kind":"independent_ru_copyedit_note","source_form_preserved_exactly":{"one":"своё занятие","few":"своих занятия","many":"своих занятий"},"note":"Root reviewer explicitly flagged “своих занятия” for editorial review. This artifact preserves the source forms verbatim. Do not silently change; ask a Russian copy editor to confirm whether “свои занятия” or another phrasing is preferred while retaining the correct counted-noun morphology."}]}}`

Suggested: `"Copy each nonempty composition-resolution editorial_notes value into the matching German unit’s editorial_notes_exact field, verbatim."`

Reason: These source notes preserve a Russian plural-form copyedit concern and explicitly say the old source forms remain unchanged pending Russian review. The German source literal/recipe is preserved, so this does not invalidate the German translation, but the note is lost from the per-unit supplement record.

Translation text change required: no

Status after structural closure: closed. The two nonempty source notes are now copied verbatim; old/new values and source provenance are recorded in the DE supplement correction history.

### DE-PROV-CONTRACTS-01 (DE, low)

Current: `{"field":"integration_contract_exact","present_in_de_ready_units":false,"source_resolution_contains_contracts_for":48,"source_contract_keys":["tracker.draft.093995ec87ba703e45e1","tracker.draft.19e098a209f2fde110ce","tracker.draft.1a4d6d93d1b328fa3369","tracker.draft.1e318cac7a56777b5fd2","tracker.draft.21e8761d3cd7c48a7965","tracker.draft.22131ffd7c2c07f5582c","tracker.draft.22dfef5eb28ed461ac5a","tracker.draft.29a3a1237d88195c4634","tracker.draft.3af68afd4be62d94fdfc","tracker.draft.3ec2feee7aadaf04f8eb","tracker.draft.52c08c717c95f8409a5e","tracker.draft.57150809b5bd9061299a","tracker.draft.5ab73dea2dd25c1e0943","tracker.draft.5c180296093f2175e7c5","tracker.draft.62267ac133c73f84a2d4","tracker.draft.64f9fb5e1de0e87d5ef2","tracker.draft.69774bbcb9432301421b","tracker.draft.6eb0ae46714a472c7cd1","tracker.draft.6f18b8c3c50ba0285e7e","tracker.draft.732c387a55591a641041","tracker.draft.74f8fef1fa7615aefbe3","tracker.draft.765c7dfb452f1e326531","tracker.draft.78c393343269e6501b4b","tracker.draft.83a4e62d2526d49dcc2d","tracker.draft.84def28e711a54b738b5","tracker.draft.8b4e4ed2b5d4ff15bfbc","tracker.draft.8f81b162870e4a56abe0","tracker.draft.923e0b844cd0feffdd17","tracker.draft.b74ad19474c15bfb0a4a","tracker.draft.c4e3c99fe51c321a4a25","tracker.draft.c8c6f09530d96b112f5c","tracker.draft.c9272236a55890917584","tracker.draft.d27f39ab16fe4f59b925","tracker.draft.d71e114cdd4d19d93b54","tracker.draft.d7bacc8fa4bed5ab16cb","tracker.draft.da1416dccbb997370865","tracker.draft.db5dc196ba061092492b","tracker.draft.df25a20804b6c982ca67","tracker.draft.e33ebe9be67195ae4f22","tracker.draft.e484ca1b0d3bf10979a1","tracker.draft.e5a679569db5ff05a9da","tracker.draft.e946acd9bd5d1d0f5bb6","tracker.draft.ee7e8f3416bf9624e0b4","tracker.draft.eefe53ffeb7ba59a31b9","tracker.draft.f4e3d7be631be3107e29","tracker.draft.f5e54f05bac32427ef1c","tracker.draft.feb3e0d3abc27a82dcfb","tracker.draft.ff1f02767a4352f91b2f"]}`

Suggested: `"Copy the exact source integration_contract into integration_contract_exact for each record where the resolution provides it, or make the German supplement explicitly depend on the pinned resolution for that field."`

Reason: The German records preserve source recipes, typed arguments and evidence but omit per-unit integration guardrails; the Italian supplement retains these contracts. This is a standalone-audit consistency gap, not an observed copy error.

Translation text change required: no

Status after structural closure: closed. All 47 missing German ready-unit contracts are now copied verbatim. The blocked CSV unit already carried its exact contract before this correction; the final 48/48 source-provided contracts match the resolution. Old/new/provenance for the 47 inserted fields are recorded in the DE supplement correction history.

## Structural findings closure

All four findings above are closed. Rechecked final structural coverage:

- Both locales still cover all 49 source keys and 103 occurrence IDs exactly once. Each has 48 translated ready units / 101 occurrences and one blocked CSV unit / 2 occurrences, with no partial CSV translation.
- DE plural `translation_coverage.plural_output_forms` now matches the materialized `one`/`other` strings for each of seven plural-bearing units; corrected total 24 (before: 84).
- IT plural `translation_coverage.plural_output_forms` now matches the materialized `one`/`other` strings for each of seven plural-bearing units; corrected total 24 (before: 28).
- DE `editorial_notes_exact` now includes the exact source arrays for `tracker.draft.eefe53ffeb7ba59a31b9` and `tracker.draft.21e8761d3cd7c48a7965`.
- DE `integration_contract_exact` now matches all 48 source records that provide the field: 47 ready records were copied in this closure, while the blocked CSV record already had the exact field. The source record without a contract remains without an invented value.
- Direct selector/enum branch sequences remain exact (60 per locale); the two uncertainty suffix selectors are also preserved. The required overlay SHA remains unchanged. All six stable error keys and both full `INVALID_INPUT` values remain exact.
- The `current`, `suggested`, and `reason` evidence for each finding remains above. Every applied change has an old/new/provenance entry in the locale supplement `correction_history`.

No translation text, Russian source, resolved source recipe, correction overlay, or runtime/app file changed.

## Scope boundary

Static/data/editorial review only. No app, runtime resource, integration, final-build rebase, Room metadata, build or device test was touched. CSV remains blocked pending stable typed error/warning payload contracts.
