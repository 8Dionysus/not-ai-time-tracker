# Независимая проверка composition supplements FR и pt-BR

Дата: 15 октября 2026 UTC  
Отдельный машиночитаемый отчёт: `translation-review-fr-pt-BR-composition.json`

## Охват и итог

Полностью вручную прочитаны все 48 готовых recipe единиц (101 occurrence) в `translations-fr-composition.json` и `translations-pt-BR-composition.json`, включая все готовые ветви, plural forms, enum states, duration formatting, error copy и Focus. Один заблокированный CSV parent с двумя occurrence остался без перевода. Сверены destructive restore/import/deletion/undo consequences, сохранение оригинальных файлов, новые записи после копии, неизвестное время, числа, статусы и технические коды. После точечных исправлений других языковых или смысловых замечаний не осталось.

## Целостность и immutable contract

- Source manifest SHA-256: `285e196dac220a2d3e95ffed48034bc04713d7e29995d8b8aedf7cb3e4cf6324`; resolution SHA-256: `af2648725aeab5817ab872a058149dcd55954e179db25c6e40d9a2e59616cfab`; обязательный overlay SHA-256: `6aee8e082c14f079d2b6e83de231bbbc92e6a096724deed10894ccf962b1a240`. Все заново сверены.
- Для всех 49 parent units совпали исходный source object, exact source hash, canonical hash resolution record, source evidence, occurrence IDs и неизменённый исходный recipe. В обоих языках 48 готовых parent / 101 occurrence; 1 blocked parent / 2 occurrences сохранены отдельно. Ни один source string, source condition или occurrence не изменён.
- Required overlay точно совпадает с обеими локалями: Room suffix остаётся optional и берётся только из SHA-verified metadata точной целевой сборки; никакой Room/JSON version не зафиксирован в видимом заголовке. Restore preview отображает локализованный consequence один раз, использует `preview.segments`, выбирает ровно одну warning slot из двух bool значений; число warnings для false/false, true/false, false/true, true/true — 0/1/1/1.
- В French пересчитаны 150 placeholder paths и прочитаны 157 output-branch strings; дополнительно проверены branch occurrence/order, все условные формы и placeholders во всех recipe. В pt-BR проверены 19 units с direct branches, 12 plural groups и 1 duration-format recipe; все branch IDs/order, числа и форматные токены сверены вручную с source recipes.
- Коды остаются неизменяемыми данными. Все шесть `error_key` сохранены в exact source recipes; каждый `error_key`/`error_code`, который явно повторяется в локализованном объекте, совпадает с source. Во French translation objects коды не дублируются, поэтому translation copy не объявляет альтернативных кодов. Проверены без перевода enum/control IDs для availability, CalendarReadIssue, notification permission, result.verified, PickMode, DAY, timer Mode, FocusMode/FocusPhase, GoalPeriod/GoalMetric/direction и GoalStatus.

## Проверенные исправления

- FR: backup history fallback теперь правильно говорит, что копия ещё не была создана с этого телефона. В промежуточном дампе до сообщения финализации около 04:55 UTC временно был текст `Même volume`; SHA этой редакции и её автор неизвестны. Первый сообщённый финальный SHA `0c496e49…` уже содержал точное `Même durée`, поэтому это наблюдение не приписано root и не считается исправлением/открытым замечанием.
- pt-BR: restore file/error mapping использует точный `tracker.error.restore_source_unavailable`; remaining error key восстановлен точно как `tracker.error.correct_no_closed_recorded_segment`. Backup consistently rendered as `cópia de segurança`, а `last == null` описывает историю создания копий именно с этого телефона.
- Полный старый/новый текст, код или условие, reason и статус каждого из семи применённых исправлений указаны в JSON-реестре.

## Границы

Финальный Sol SHA не предоставлен; до интеграции необходимо rebasing против точного final target commit и повторная проверка версии Room и producer/mapping restore preview на этой сборке. Не выполнялись build/test, runtime/device UI, accessibility или native-speaker QA. Эти data-only supplements не подтверждают поддержку locale или production readiness.
