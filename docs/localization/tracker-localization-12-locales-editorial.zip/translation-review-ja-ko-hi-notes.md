# Independent Tracker translation review — ja, ko, hi-IN

Date: 2026-10-15  
Source manifest SHA-256: `285e196dac220a2d3e95ffed48034bc04713d7e29995d8b8aedf7cb3e4cf6324`  
Review file: `translation-review-ja-ko-hi.json`

## Final-snapshot coverage

- `ja`: 376/376 ready units and 402/402 variants; source text, conditions, 402 source hashes, placeholders, and 437 ready occurrence assignments verified. The 54-unit remainder carries all 126 deferred IDs. Final package SHA-256: `7202dc244527134300b1459c52cef42dba780df1e98bad41fa27681b4f0c452f`.
- `ko`: 376/376 ready units and 402/402 variants; source text, conditions, 402 source hashes, placeholders, and all 563 occurrence IDs verified. Parent’s note-preserving-start, resume, and segment-change corrections were checked at their exact keys. Final package SHA-256: `66422a760c5c8fe9e341c4b7414ab69c736ab57b7c3c8bf2ea01fb93ee8801c2`.
- `hi-IN`: 376/376 ready units and 402/402 variants; 25 conditional units contain 51 variants. Exact source text, conditions, unit/variant IDs, 402 source hashes, typed placeholders, and placeholder-token multisets verified. All 563/563 manifest occurrence IDs occur once across ready and remainder (437 ready + 126 deferred). Remainder: 49 `needs_composition` + 5 `non_translatable` = 54 units. Final package SHA-256: `8d5ad7320e91cf4a56f35bc6c1dd4d489dd2775be071f18603d378fb933c3370`.
- The immutable manifest hash matches the expected `285e196d…f6324`. All package hashes above were recomputed from the current files.

## Hindi correction audit

- The original 20 open HI findings are now resolved in the final base. Every current string was rechecked at its exact draft key and condition. The Stop label stays `रोकें`; changing the paired Pause label to `विराम` resolves their former collision.
- All 23 records in `translations-hi.json` → `review_corrections` were independently matched to the final base by key, variant condition, exact source string, source SHA-256, previous translation, and new translation. The audited history is copied into the JSON review artifact.
- The earlier flattened-index error was repaired at the three exact adjacent rows: “Оставить без занятия” → “बिना गतिविधि के जारी रखें”; “Завершение интервала Focus” → “फ़ोकस अंतराल पूरा हुआ”; “Focus: интервал завершён” → “फ़ोकस: अंतराल पूरा हुआ”. The next-step instruction remains separately at its own key.
- Four additional corrected rows are recorded in the review history: an activity-picking description, two keyed instances of “Переключиться на”, and the overlay-button description. Together with the Stop/Pause resolution, there are 24 resolved historical review entries and 23 direct changed-string records. No unresolved Hindi translation-specific finding remains from this pass.

## Number, count, and phase notes

- Hindi count-sensitive morphology is used where needed: `गतिविधियाँ` in “दो या तीन गतिविधियाँ” and `हाल की गतिविधियाँ”; the multiple-widget branch has its count and plural predicate. The borrowed counted noun `विजेट` is invariant after numerals.
- Hindi direct count constructions use forms like `N मिनट`, `N दिन`, `N रिकॉर्ड`, `N क्षेत्र`, `N खंड`, and `N सत्र` without English-style plural endings. `N मिनट का काम` correctly marks the relation to `काम` with `का`. Do not translate or pluralize runtime-formatted duration values or user/catalog values.
- `नए कार्ड: N` is a compact count-category label, not a full subject-predicate sentence; its generic plural label is intentional for dynamic values. Native Hindi/UI-fit review can confirm this terse label convention.
- Dynamic `$phase` text uses the neutral frame `चरण पूरा हुआ: $phase`, so both `काम` and `विराम` fit without gender agreement.

## Semantic review and release caveat

The full static pass reviewed undo-success versus cancel, retained prepared files after canceled export, CSV append meaning (import app records), restore/rollback, unknown-time exclusions, deletion, statuses, counts, and dynamic phase labels. JA and KO have no open locale-specific issue in this review; the HI corrections are verified as above.

A shared source-copy caution remains for all three locales: immutable source `tracker.draft.5027e9837e3ca3339a41` says all data is only on the phone, while `translation-semantic-context.json` records that explicit user-selected exports can go to external/cloud-backed destinations. Resolve at shared source/data-flow level after confirming release behavior; do not repair only one locale.

This was a static/editorial review only. No application, runtime, build, tests, device rendering, or base translation files were changed or exercised. Native-language and UI-fit review remains advisable.
