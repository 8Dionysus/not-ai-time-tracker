# Arabic composition supplement: editorial notes

## Deliverable and provenance

- `translations-ar-composition.json` is an append-only, translator-facing data supplement for Arabic (modern standard Arabic). It is data-only; integration and runtime verification remain pending.
- Source resolution: `composition-resolution.json`, SHA-256 `af2648725aeab5817ab872a058149dcd55954e179db25c6e40d9a2e59616cfab`.
- Required correction overlay: `composition-correction-overlay.json`, SHA-256 `6aee8e082c14f079d2b6e83de231bbbc92e6a096724deed10894ccf962b1a240`.
- Parent source manifest: `translation-units.json`, SHA-256 `285e196dac220a2d3e95ffed48034bc04713d7e29995d8b8aedf7cb3e4cf6324`.
- Output JSON SHA-256: `333ac3ff55ac071264e0a51f1351c234d7d2e190d9e25e30dbaf7ac30bf00ff7`.
- Existing reviewed Arabic base package remains unchanged: `translations-ar.json`, SHA-256 `4c4c31ac858a282036f237ad626c003f2ec1826fc1a1b5a806c81889201b481b`.
- Existing reviewed Arabic plural supplement remains unchanged: `translations-ar-plurals.json`, SHA-256 `2b6575e06344b9d4ffa37083451549c4812d0ee343c52358f2c42e5fedfa92b8`.

## Coverage and static checks

The supplement covers all 48 translation-ready composition units and all 101 associated occurrence IDs. The one blocked CSV-import dialog remains explicitly blocked with its two source occurrences, `UI-9eb89e6c-cf8364-L0279-C025` and `UI-9eb89e6c-cf8364-L0279-C210`; no partial or speculative Arabic copy is proposed for it. The source resolution and original parent manifest were both checked for exact parent-key and occurrence-ID coverage.

Each ready unit keeps the exact Russian `source_ru_exact` and the exact baseline resolved recipe in separate fields. Original source conditions, enum names, occurrence IDs, error keys/codes, producer expressions and technical argument mappings are copied verbatim. The overlay’s full records, including prior values, review findings and replacement contracts, are preserved on the affected entries; Arabic proposals follow those corrected contracts without replacing the original source evidence.

Static checks passed for: 48/101 ready coverage, blocked 1/2 coverage, source-recipe equality, overlay and input hashes, branch counts, placeholder-token allowlisting, exact error-key/error-code preservation, absence of hidden bidi controls, and plural-category completeness. These checks do not certify an application API, build, runtime behavior, or visual UI rendering.

## Mandatory corrected contracts

- Restore preview uses `sessions ← preview.sessions`, `segments ← preview.segments`, and `goals ← preview.goals`. It does not substitute `preview.cards` for segments. The translated `consequence` slot reuses `tracker.draft.c4e3c99fe51c321a4a25` and renders exactly once.
- The two unfinished flags are evaluated together and select exactly one warning: neither, tail only, Focus only, or both. The both case has one combined unknown-time consequence and says both times need clarification. It never concatenates the two single-flag warnings.
- The diagnostic-panel Room suffix comes only from verified metadata for the exact final target build, tied to its final SHA. If that metadata is missing or unverified, omit the suffix. Do not hardcode `Room 5`, `Room 6`, or `JSON 8`.
- Backup-history fallback is `لم تُنشأ نسخة احتياطية من هذا الهاتف بعد`: no backup has yet been created from this phone. This does not claim the device contains no files.
- Where the source says files remain saved, Arabic communicates retention only; it does not promise that a new export or destination write completed. The undo wording for deletion means reversing an already completed deletion, consistent with the `undo(token)` caller, rather than cancelling a pending operation.
- The CSV import dialog remains blocked because its nested error and warning lists lack stable typed localization contracts. Arbitrary row errors and warnings are not translated or guessed.

## Arabic pluralization

The package uses the Arabic cardinal categories specified by CLDR 49 for integer counts:

- `zero`: n = 0
- `one`: n = 1
- `two`: n = 2
- `few`: n % 100 = 3..10
- `many`: n % 100 = 11..99
- `other`: all remaining values

The 12 counted-noun argument entries in the composition supplement each include all six forms. Tested selector results: 0→zero, 1→one, 2→two, 3→few, 10→few, 11→many, 99→many, 100→other, 102→other. Exact count argument/source expressions are recorded with each plural object. In `one` and `two`, the numeral is intentionally absent only where Arabic singular/dual morphology conveys the exact value (for example `جلسة واحدة` / `جلستان`); the numeric argument remains active in the selector, and the rendering branch must be guarded by n=1 or n=2. In the goal-status count branch, the nested `{count}` form argument is explicitly mapped to `{amount}` and is used only for `GoalMetric.COUNT`.

Plural rules and Arabic unit grammar were checked against the primary Unicode CLDR charts:

- [CLDR 49 Language Plural Rules](https://unicode.org/cldr/charts/49/supplemental/language_plural_rules.html)
- [CLDR 49 Arabic Unit Grammar Info](https://unicode.org/cldr/charts/49/grammar/ar.html)

## RTL integration requirement

No invisible bidi control characters have been added to Arabic copy or placeholder tokens. At integration, use the platform’s bidi isolation facilities at render time for interpolated Latin or opaque values embedded in Arabic UI, including error codes/IDs, file names and paths, catalog/user labels, version strings, IANA time-zone IDs, timestamps, durations/byte counts and revision integers. Do not insert bidi controls into localized strings or tokens. Mixed Arabic/Latin rendering still needs UI-level visual verification in the target build.
