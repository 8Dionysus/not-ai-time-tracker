# Arabic editorial translation — Tracker prepared slice

- Source manifest: `translation-units.json`
- Source manifest SHA-256: `285e196dac220a2d3e95ffed48034bc04713d7e29995d8b8aedf7cb3e4cf6324`
- Target locale: `ar` (modern standard Arabic)
- Output: `translations-ar.json`; follows the `translations-en.json` translation-draft schema.
- Status: complete editorial pass for the prepared slice; draft for native-language and UI review, not production-ready.
- Coverage: all 376/376 `ready_for_translation` units and 402/402 variants translated, including all 25 conditional units / 51 conditional variants.
- Remainder: 49 `needs_composition` and 5 `non_translatable` units are retained explicitly from the source manifest, without invented translations; full source fields, exact text and occurrence IDs are retained.
- Integrity checks passed: exact manifest SHA and source snapshot retained; ready-key order and uniqueness; exact source text, condition branches, placeholder metadata and occurrence IDs joined against the source; source-text SHA-256 for all 402 variants; exact placeholder-token multisets; each source occurrence ID represented exactly once across translated units and the retained remainder.
- Undo wording: `tracker.draft.d1addc4a5f6d758c11c5` uses `تم التراجع` (“Undone”), matching `caller rt.tracker.undo(token)` after a prior change. It does not mean cancel/cancellation. The Russian source remains unchanged.
- Editorial terms: Focus → `التركيز`; activity → `نشاط`; entry → `سجل`; card → `بطاقة`; catalog → `الفهرس`; report time zone → `المنطقة الزمنية للتقارير`. Brand names, user/catalog values, identifiers, protocol strings and wire values are not translated.
- Review the fit of longer Arabic strings on compact Android surfaces and the conventional Arabic UI phrasing, plus truncation, accessibility labels and locale formatting. No app launch, build, runtime/device QA, or generated-resource validation was performed.

## Separate RTL integration requirement

The translated strings contain no inserted invisible bidi controls, including inside placeholders. In the RTL presentation layer, isolate dynamic LTR values and mixed-direction runs (for example IDs, ISO/CSV/JSON values, time-zone IDs, Latin brand names, numeric values and interpolated user/catalog text) using the platform's bidi formatting/isolation support. Handle layout direction and punctuation/order at rendering time; do not mutate placeholder tokens or persist bidi marks in these translation strings.

## Scope

Only local prepared translation data was used. No application, runtime tests, external translation service, Pages, repository, or additional agents were used.

## Independent review corrections

A full independent AR review was applied without changing the source manifest, source text, counts, placeholders, conditions, occurrence IDs or SHA fields. All ten AR findings are recorded in `translations-ar.json` under `review_corrections`, with exact old text, resolved new text/forms, reviewer suggestion and reason. Six findings update their Arabic strings directly; the four count+noun findings are resolved by `translations-ar-plurals.json`. For those four, the flat `translation` field is explicitly the CLDR `other` form only and must not be used for every count.

The six direct wording edits clarify the catalog preview, existing-history report behavior, verified backup hashes before replacement, retained prepared export files, the destination of CSV append (records go into the app), and assigning an activity to the current record. Source and data values remain unchanged. The undo toast remains `تم التراجع`, meaning a previously applied action was undone.
