# Arabic count-and-noun plural add-on

- Companion data: `translations-ar-plurals.json`
- Source manifest SHA-256: `285e196dac220a2d3e95ffed48034bc04713d7e29995d8b8aedf7cb3e4cf6324`
- Locale: `ar`; CLDR rule set: cardinal, version 49.
- Four count+noun keys from AR-07 through AR-10 are included: the two minute labels, Focus work minutes, and the additional-areas label.
- Their exact source count arguments and `integer_or_count` types are copied from the prepared source metadata. Each retains its source text, source SHA-256, occurrence IDs, and typed placeholder metadata.

## Verified Arabic CLDR categories

Unicode CLDR 49 defines these Arabic cardinal categories:

- `zero`: n = 0
- `one`: n = 1
- `two`: n = 2
- `few`: n mod 100 = 3..10
- `many`: n mod 100 = 11..99
- `other`: every remaining value

For the integer counts used by these four entries: 0 → zero, 1 → one, 2 → two, 3 and 10 → few, 11 and 99 → many, and 100 and 102 → other. `other` is a real rendering form; no single `n دقيقة` string is treated as correct for all values. The source arguments are integer/count values, not decimal quantities.

The Arabic CLDR unit-grammar chart identifies `دقيقة` as feminine and uses `دقيقة واحدة` for one; its Arabic plural minimal pairs show count + plural noun for `few`, count + accusative singular for `many`, and count + singular for `other`. The count labels use standalone/nominative dual forms for 2 (`دقيقتان`, `مجالان`). Forms with an accusative tanwin in `many` follow the CLDR Arabic sample pattern; UI review may confirm preferred diacritic policy.

Primary Unicode sources:

- [CLDR 49 Language Plural Rules](https://unicode.org/cldr/charts/49/supplemental/language_plural_rules.html)
- [CLDR 49 Arabic Unit Grammar Info](https://unicode.org/cldr/charts/49/grammar/ar.html)

## One and two branch handling

Arabic one/two forms are intentionally rendered without the digit token, e.g. `دقيقة واحدة` and `دقيقتان`; area forms use `مجال إضافي واحد` and `مجالان إضافيان`. The exact source count argument is still evaluated and passed to the category selector. The data requires a guard of `count == 1` or `count == 2` before selecting the corresponding output; the argument is not discarded. For zero/few/many/other, the exact source count placeholder remains once in the rendered text, and other placeholders such as `$title` are preserved.

The add-on includes concrete vectors for 0, 1, 2, 3, 10, 11, 99, 100 and 102, per-key rendered examples, and static checks for the source joins and placeholder behavior. These are data-level checks only; no application, runtime, UI, or device tests were run. The existing Arabic RTL requirement remains: isolate dynamic LTR values at render time, and do not insert bidi controls into stored strings or placeholders.
