# Tracker: Deutscher Anhang für zusammengesetzte UI-Texte

## Umfang und Status

`translations-de-composition.json` enthält den deutschen redaktionellen Entwurf für alle 48 Einheiten mit Status `translation_ready_but_integration_pending` und deren 101 Vorkommen. Die Gesamtquelle enthält 49 Einheiten und 103 Vorkommen; die CSV-Import-Einheit `tracker.draft.d7bacc8fa4bed5ab16cb` bleibt mit beiden Vorkommen explizit blockiert und ohne deutsche Übersetzung. Das Dokument ist ein Daten-/Übersetzungsentwurf, keine Integration und keine Runtime-Ressource.

- Quellmanifest `translation-units.json`: SHA-256 `285e196dac220a2d3e95ffed48034bc04713d7e29995d8b8aedf7cb3e4cf6324`.
- `composition-resolution.json`: SHA-256 `af2648725aeab5817ab872a058149dcd55954e179db25c6e40d9a2e59616cfab`.
- Obligatorisches `composition-correction-overlay.json`: SHA-256 `6aee8e082c14f079d2b6e83de231bbbc92e6a096724deed10894ccf962b1a240`.
- Die DE-Basisdatei blieb unverändert: `translations-de.json` SHA-256 `9d261a5b7ec42ae6da7ff337f35dbaf266d6fd4d0a94120292f47dba6785728`; Reviewdatei `translation-review-de.json` SHA-256 `642e338c8aba36cf43dd62f7ee31406118a03b3c31bdb9f3f9f53a8cdd51e7b6`. Der Review-`after_sha256` entspricht der Basisdatei.
- Deutsche Kopie behält pro Einheit exakte russische Quelltexte, ursprüngliche aufgelöste Rezepte, typisierte Argumente, Vorkommens-IDs, Evidenz und kanonische SHA-256-Prüfsummen bei. Alte Werte und Findings bleiben im unveränderten Overlay-Auditobjekt getrennt vom deutschen korrigierten Vorschlag.

## Korrigierte Overlay-Rezepte

1. `tracker.draft.f4e3d7be631be3107e29` (technisches Diagnosefeld): Die deutsche Vorlage verwendet `{roomSchemaSuffix}`. ` · Room {roomSchemaVersion}` darf nur aus SHA-verifizierten Metadaten des exakten endgültigen Builds (`Room @Database(version=...)` oder gleichwertige generierte Build-Metadaten) stammen. Wenn Version oder Build-SHA nicht verifiziert ist, bleibt das gesamte Suffix leer. Die alte russische Quelle mit „Room 5“ bleibt nur als Auditwert erhalten; weder Room 5/6 noch JSON-Backupversion 8 werden fest codiert. Die erforderliche endgültige Sol-Rebase-/Metadatenprüfung steht noch aus.
2. `tracker.draft.1a4d6d93d1b328fa3369` (Wiederherstellungsvorschau): Die Anzahl unter „Segmente“ wird ausschließlich aus `preview.segments` bezogen, niemals aus `preview.cards`. Die lokalisierte Konsequenz `{consequence}` wird genau einmal eingesetzt. Aus den beiden Flags wird gemeinsam genau eine von vier Varianten ausgewählt: weder noch (0 Warnsätze), nur Timer-Intervall (1), nur Focus-Intervall (1), beide (1 kombinierter Warnsatz). Jede Warnung erhält den Hinweis, dass Zeit unbekannter Dauer wiederhergestellt wird und anschließend geklärt werden muss.

## Branches, Platzhalter und Redaktion

- Erhaltene deutsche Ausgabezweige: 60 direkte Varianten, 16 verschachtelte Argumentzweige, 2 Suffixzweige, 6 Enum-Werte sowie 12 Pluralgruppen mit 24 Formen. Deutsche Pluralgruppen verwenden `one` / `other`; Mengen und Einheiten bleiben unverändert.
- 57 gemeinsam gerenderte Branch-/Template-Pfade wurden gegen die englische Struktureferenz auf exakte Platzhalter-Multimengen geprüft. Die strukturelle Referenz diente nur als Branch-/Platzhaltervergleich; originale RU-Quellwerte und Rezepte bleiben maßgeblich.
- `translation-semantic-context.json` wurde für das Undo-Wording gelesen: Die Aktion wurde bereits rückgängig gemacht, nicht vor Ausführung abgebrochen. Die vorhandene Base-Formulierung „Rückgängig gemacht“ passt zu diesem Sinn.
- Benutzerdefinierte Namen, Katalogtexte, IDs, IANA-Zeitzonen, Enum-/Wirecodes und sonstige technische Werte sind Daten und werden nicht übersetzt. Zahl-, Datum-, Uhrzeit- und Dauerformatierung bleibt Aufgabe der deutschen Locale-Formatter; gespeicherte Werte/Zeitpunkte werden nicht verändert.
- Der CSV-Import bleibt gesperrt, weil die Fehler-/Warnungslisten dynamische freie Payloads ohne übersetzungssicheren typisierten Vertrag enthalten. Der Quelltext, die Blockierungsbegründung und beide Vorkommens-IDs sind im Auditdatensatz enthalten; keine Teilübersetzung wurde erfunden.

## Validierung und Grenze

Programmatisch geprüft wurden die exakten 49 Parent-Keys und 103 Occurrence-IDs, der Umfang von 48 übersetzten Einheiten / 101 Vorkommen, beide getrennten Korrekturverträge und deren Overlay-SHA, die Herkunfts-/Quellhashes, typisierten Argumente, Variantenreihenfolge, Enum-/Plural-/Suffix-/Argumentzweige, Platzhalter, den vierstufigen Restore-Wahrheitstisch (Warnungen 0/1/1/1) sowie, dass die DE-Basisdatei unverändert blieb. Room-Metadaten für den endgültigen Build sind nicht nachgewiesen; deshalb bleibt die Integration bis zur finalen SHA-gebundenen Rebase-Prüfung ausstehend. Es wurden weder App-Code, Runtime-Dateien, Pages noch Builds oder Gerätetests geändert bzw. ausgeführt.
