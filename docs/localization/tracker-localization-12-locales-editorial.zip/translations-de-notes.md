# Deutsche Übersetzung von Tracker — vorbereiteter Ausschnitt

- Quellmanifest: `translation-units.json`
- SHA-256 des Quellmanifests: `285e196dac220a2d3e95ffed48034bc04713d7e29995d8b8aedf7cb3e4cf6324`
- Quell-Snapshot: alle 24 Quell-Blob-Hashes sind in `translations-de.json` enthalten.
- Zielsprache: `de` (allgemeines Deutsch; konsequente, informelle Du-Ansprache in nutzergerichteten Formulierungen).
- Status: **redaktioneller Entwurf zur Prüfung durch deutschsprachige Personen und zur UI-Prüfung**, nicht produktionsbereit.
- Umfang: 376/376 Einheiten mit `ready_for_translation` übersetzt; 402/402 Quelltextvarianten übersetzt; 25 bedingte Einheiten mit 51 Zweigen; keine übersetzungsreifen Einheiten blockiert.
- Occurrence-Abdeckung der übersetzungsreifen Einheiten: 437/437 IDs auf Einheiten- und Variantenebene genau einmal abgedeckt.
- Weiterhin ausdrücklich zurückgestellt: 49 Einheiten `needs_composition` und 5 `non_translatable` (54 insgesamt). Status und Quellinhalt sind im JSON erhalten; keine fehlende Formulierung wurde ergänzt.
- Prüfungen: Reihenfolge, Vollständigkeit und Eindeutigkeit der 376 Schlüssel; 402 Varianteneinträge samt unveränderten Bedingungen, Quelltexten, Quell-Occurrence-IDs und Quelltext-SHA-256; exakte Gleichheit aller Platzhalter-Tokens und Typ-Metadaten: **bestanden**. Das Quellmanifest hat den erwarteten SHA-256.
- Redaktionelle Leitlinien: `(not)AI`, Nutzernamen und Katalog-/Aktivitätswerte, technische Wirecodes wie `Start` und `Switch`, IDs, Codes, Formate, Parameter und Platzhalter bleiben unverändert. Hinweise zu CSV-Import, Wiederherstellung, Austausch von Daten und Rückgängig-Aktionen behalten ihre genannten Folgen und Einschränkungen.
- Gewünschte Nachprüfung: idiomatische Formulierungen, Konsistenz der Fachbegriffe, Länge und mögliche Kürzung, Barrierefreiheit sowie Darstellung dynamischer Platzhalter in Android-Oberflächen. Die Prüfung ist statisch; es wurden kein Build, keine Tests, kein App-Start und keine Geräte-/UI-Prüfung durchgeführt.
- Grenze des Umfangs: ausschließlich lokale Übersetzungsdaten und Notes. Kein App-Code, keine Runtime-Ressourcen, keine Pages und keine Zugriffsrechte wurden geändert. Dieser Entwurf lokalisiert nicht die vollständige Anwendung; zurückgestellte Einheiten und weitere Sprachen liegen außerhalb dieses Pakets.
