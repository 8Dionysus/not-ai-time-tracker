# Traducción de recipes de composición al español

## Estado

Borrador editorial en español para **48 recipes listos para traducción** del análisis append-only. El análisis de origen registra **49 unidades y 103 ocurrencias**: se tradujeron las 48 unidades listas (101 ocurrencias); 1 unidad (2 ocurrencias) permanece bloqueada, sin traducir, porque el texto de errores y advertencias importados es dinámico, libre y carece de contrato de localización tipado. No se presenta como integración completada ni como API/runtime existente.

- Archivo de salida: translations-es-composition.json
- SHA-256 de composition-resolution.json: af2648725aeab5817ab872a058149dcd55954e179db25c6e40d9a2e59616cfab
- SHA-256 del snapshot padre translation-units.json: 285e196dac220a2d3e95ffed48034bc04713d7e29995d8b8aedf7cb3e4cf6324
- Total parent draft keys exactas: 49; traducidas: 48; bloqueadas: 1
- Cobertura exacta del origen: 49/49 parent keys y 103/103 occurrence IDs; objetivo traducido: 48/48 ready keys y 101/101 ready occurrence IDs
- Placeholders de templates/ramas emparejados programáticamente: 111 comparaciones; todas conservaron la misma multiconjunción de tokens
- Ramas/plurales/condicionales/estados enumerados con salida ES cubiertos: 104 strings de rama según conteo por unidad en el JSON
- Source RU, claves parent, receta resuelta y argumentos tipados se copian exactamente en cada registro; cada receta también conserva sus occurrence IDs y el contexto de source evidence.

## Exclusión bloqueada

tracker.draft.d7bacc8fa4bed5ab16cb queda explícitamente como blocked_pending_typed_payload_contract, con translation_es: null. La unidad incluye {addedCount}, {duplicateCount}, {rowSummary}, {errorCount}, {firstErrors} y {warnings}. Los errores/avisos internos pueden incluir texto libre y mensajes CoreError; traducir solo la capa exterior ocultaría que la superficie seguiría parcialmente en otro idioma. Se requiere un contrato tipado para esas listas o retirarlas de la superficie traducida.

## Observaciones semánticas para revisión

1. En tracker.draft.1a4d6d93d1b328fa3369, la plantilla de origen nombra {unfinishedTailLabel} / {unfinishedFocusLabel}, mientras que los argumentos condicionales tipados son unfinishedTailSentence / unfinishedFocusSentence. Se conservan ambos nombres del source sin reconciliarlos; confirmar el mapeo de integración.
2. En tracker.draft.c9272236a55890917584, {overlayStatus} es un estado tipado/localizado, pero esta receta no enumera sus valores. La copia pasa el token intacto; verificar su recurso de destino al integrar.
3. En el informe tracker.draft.df25a20804b6c982ca67, el contrato acepta un ID IANA exacto o un nombre localizado de zona horaria. El texto no fuerza una elección; conservar el ID como dato si se muestra.
4. Los plurales usan categorías españolas CLDR one / other (cero y cualquier valor distinto de uno usan other); la fecha/hora, la duración, los números y las listas quedan al formato es al integrar, sin recalcular valores.
5. El ruso “своих занятия” de tracker.draft.eefe53ffeb7ba59a31b9 y tracker.draft.21e8761d3cd7c48a7965 tiene un error gramatical. La traducción española es gramatical y refleja el significado; source_ru_exact se conserva literalmente para auditoría.
6. Room 5 y Focus se mantienen como nombres/identificadores de origen; los nombres de actividad, catálogos, metas y etiquetas del usuario se conservan como contenido, sin traducir.
7. Por separado, para el toast tras deshacer (tracker.draft.d1addc4a5f6d758c11c5) recomiendo «Se deshizo»: el contexto comunica que la acción se revirtió; «Cancelado» puede entenderse como cancelar una acción antes de ejecutarla. La corrección de ese paquete previo queda pendiente del QA conjunto del parent.

## Comprobaciones

Se validaron por programa las claves de 49 parent units, 48 traducciones ready y la unidad bloqueada; los 103 occurrence IDs únicos; igualdad exacta de source RU/recetas/argumentos tipados; presencia y orden de ramas de variantes; cobertura one/other, condicionales y enum; enlaces a recetas padre; y multiconjuntos de placeholders, incluida la grafía exacta de tokens con formato como {minutes:2-digit}. No se ejecutaron build, tests ni código de producto; no se integró esta copia en el runtime.
