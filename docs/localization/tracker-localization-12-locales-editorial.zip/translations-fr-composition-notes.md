# Tracker French composition supplement — editorial notes

Target: neutral French UI (`fr`). This supplement covers all 48 `translation_ready_but_integration_pending` composition parents and all 101 associated occurrences. The one CSV error/warnings parent and its two occurrences remain blocked, with exact Russian source and a French blocker note; no partial translation or invented semantic mapping is supplied.

## Provenance and source preservation

- Immutable parent translation inventory SHA-256: `285e196dac220a2d3e95ffed48034bc04713d7e29995d8b8aedf7cb3e4cf6324`.
- `composition-resolution.json` SHA-256: `af2648725aeab5817ab872a058149dcd55954e179db25c6e40d9a2e59616cfab`. Each unit retains exact `source_ru_exact`, exact original `resolved_source_recipe_exact`, typed arguments, occurrence IDs, source evidence, editor notes and integration contract. Canonical-JSON SHA-256 values are included per original source record and per exact Russian source object.
- Required `composition-correction-overlay.json` SHA-256: `6aee8e082c14f079d2b6e83de231bbbc92e6a096724deed10894ccf962b1a240`. Each corrected unit includes the overlay review/evidence metadata and exact replacement contract, each tied to the full-record canonical hash. Prior EN/ES values held only in the overlay’s audit history are excluded from the FR supplement; the overlay replacement contract drives French. Original Russian text and original recipe remain audit source.
- Spanish and English composition files were used only as structural/placeholder cross-check references (`e35b48c8d0f8dd9ee049b979e1885994b1cbaed6601032338240be1d7a414c48` and `f7fe3022ff9ff3dc6ebcb39280d99ed07b6a6352c01b4c4d1399d68b562db413`); older strings for the two corrected keys were not copied. `translations-fr.json` was not changed.
- This is editorial data only; no UI/runtime/source changes.

## Corrected overlay contracts

1. `tracker.draft.f4e3d7be631be3107e29` (technical panel): the French template uses optional `{roomSchemaSuffix}`. Render ` · Room {roomSchemaVersion}` only when Room schema version is verified from the exact final target build and tied to that build SHA; otherwise omit the entire suffix. Never hardcode Room 5, Room 6, or JSON backup format version 8. `{timerStatus}`, `{focusStatus}`, `{selection}`, `{report}`, `{trustedDuration}`, and `{revision}` remain typed/formatted arguments, not guessed constants. Exact Russian source still contains Room 5, preserved solely for audit.
2. `tracker.draft.1a4d6d93d1b328fa3369` (restore preview): the overlay template is `{consequence}\nСессий: {sessions}; сегментов: {segments}; целей: {goals}.{unfinishedDataSentence}`. French rendering is one template plus the four exhaustive cases `neither`, `tail_only`, `focus_only`, `both`. Select one case from the two flags together; warning counts were checked as 0/1/1/1. The both-true case uses one combined warning. Render translated consequence exactly once. Counts map `sessions ← preview.sessions`, `segments ← preview.segments` (never cards), `goals ← preview.goals`; values are locale-formatted without changing magnitude. Exact older Russian composed source stays separate from the corrected recipe.

## Completeness and formatting

- Exact coverage: 49 parent keys / 103 occurrence IDs, with 48 ready parents / 101 ready occurrences translated and the 1 blocked parent / 2 occurrences explicitly held.
- All branches, enum outputs, nested conditional strings and plurals in ready recipes are represented. All original occurrence IDs and source evidence are retained. For unchanged recipes, every shared source branch keeps its exact placeholder multiset; the two overlay recipes are checked against overlay canonical placeholders.
- French cardinal forms follow CLDR (`one`, `other`, and `many`). In this material, `many` and `other` use the same French plural noun form. Integer 0 follows the CLDR `one` category. See Unicode CLDR French plural rules: https://unicode.org/cldr/charts/49/supplemental/language_plural_rules.html.
- Use French number grouping/decimal conventions and active locale date/time formatters; do not change numeric quantities, timestamp instants, zone IDs, trusted millisecond durations, or canonical milliseconds. Preserve exact `{minutes:2-digit}` where shown. Catalog/user-authored names, titles, opaque IDs, enum/wire values and technical identifiers remain unlocalized. Dynamic diagnostic/import/error values remain typed payloads and are not translated blindly.

## Generated checks

The JSON records immutable source hashes and counts. Validation verified unique parent and occurrence coverage, original source hashes, exact source text and evidence retention, placeholder multisets for shared branches, correction-overlay source hashes and contents, and all four restore-flag outcomes.
