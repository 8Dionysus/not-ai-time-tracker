# Traduction française de Tracker — tranche préparée

- Manifeste source : `translation-units.json`
- SHA-256 du manifeste source : `285e196dac220a2d3e95ffed48034bc04713d7e29995d8b8aedf7cb3e4cf6324`
- Instantané source : les 24 hachages des blobs source sont repris dans `translations-fr.json`.
- Langue cible : `fr` (français général, ton d’interface cohérent avec le vouvoiement).
- Statut : **brouillon à faire relire par une personne de langue maternelle et à vérifier dans l’interface**, pas prêt pour la production.
- Couverture : 376/376 unités `ready_for_translation` traduites, 402/402 variantes source traduites (25 unités conditionnelles ; 51 variantes conditionnelles) ; aucune unité prête bloquée.
- Occurrences sources des unités prêtes : 437/437 couvertes exactement une fois. Les ID d’occurrence, conditions, textes source et hachages de texte source sont conservés.
- Reste explicitement hors traduction : 49 unités `needs_composition` et 5 unités `non_translatable` (54 au total). Ces deux catégories figurent séparément dans le JSON, avec leur statut et leur contenu source conservés ; aucune formulation manquante n’a été reconstituée.
- Vérifications : égalité et ordre des clés prêtes, couverture des variantes, conservation des conditions et ID d’occurrence, égalité exacte des placeholders et SHA-256 UTF-8 des 402 textes source : **réussis**. Le SHA-256 actuel du manifeste correspond à la valeur attendue.
- Choix éditoriaux : le nom de marque et les noms de catalogue saisis par l’utilisateur sont conservés ; les valeurs de commande techniques (`Start`, `Switch`), les codes, noms de paramètres, formats, identifiants et placeholders restent inchangés. Les avertissements concernant le remplacement, la restauration, les données et les exports ont été traduits sans supprimer leurs conséquences ou conditions.
- Relecture souhaitée : naturel et cohérence de la terminologie, longueur/troncature, accessibilité, présentation des placeholders dynamiques et adaptation des libellés aux surfaces Android. La vérification de couverture est statique : aucun build, test, lancement d’application, rendu de notification ou contrôle sur appareil n’a été effectué.
- Périmètre : livrable éditorial local uniquement. Aucun code, dépôt, réglage d’accès, ressource d’application ou fichier source du manifeste n’a été modifié. Ce brouillon ne constitue pas une application entièrement localisée ; les unités différées et les autres langues demandées restent hors de ce lot.
