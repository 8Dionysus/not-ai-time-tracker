# Hindi composition supplement — editorial notes

Status: completed Hindi (hi-IN) editorial composition draft for 48 ready static recipes / 101 occurrences. The single CSV import-preview unit remains blocked (2 occurrences) with no partial translation. All entries remain integration-pending; this file does not claim the application has Hindi runtime resources or has passed build/device QA.

## Inputs and integrity

- translation-units.json — SHA-256 285e196dac220a2d3e95ffed48034bc04713d7e29995d8b8aedf7cb3e4cf6324
- composition-resolution.json — SHA-256 af2648725aeab5817ab872a058149dcd55954e179db25c6e40d9a2e59616cfab
- composition-correction-overlay.json — SHA-256 6aee8e082c14f079d2b6e83de231bbbc92e6a096724deed10894ccf962b1a240
- translation-semantic-context.json — SHA-256 cf35e1042130b9c228f687427df14a9bb110a7fe0359000a7e6e74c75a1ee72b
- translation-review-ja-ko-hi.json — SHA-256 12364869c542b42d5cd95bcb59bfcc169fef7fe806fbaa2e95d4f3790b4ca4cc
- Accepted base translations-hi.json (target_locale: hi-IN) and translations-hi-notes.md were reviewed. Base SHA-256 remains 8d5ad7320e91cf4a56f35bc6c1dd4d489dd2775be071f18603d378fb933c3370.
- Final translations-hi-composition.json after independent semantic review — SHA-256 6da12fa497d6d51ba53abc7cdefffcbfea80b410abc263ce9af26b6c14e2a373

## Overlay corrections

The original Russian source object, baseline resolved recipe, typed arguments, evidence, source hashes, and occurrence IDs are preserved exactly. The source correction overlay and per-unit composition_correction_provenance retain the prior values and corrected contract separately.

- tracker.draft.f4e3d7be631be3107e29: use तकनीकी इंटरफ़ेस{roomSchemaSuffix}. The suffix is exactly “ · Room {roomSchemaVersion}” only when verified metadata from the exact final target build is available; it is empty when missing or unverified. No fixed Room 5, Room 6, or JSON 8 is asserted. Final-SHA rebase and metadata verification remain required before integration.
- tracker.draft.1a4d6d93d1b328fa3369: the replacement template reuses {consequence} once and selects one {unfinishedDataSentence} for the four unfinishedTail / unfinishedFocus combinations. The two-true case is one combined warning with one unknown-time consequence, and asks the user to clarify both affected times. {segments} is the preview segment count (preview.segments), as mapped by the preserved overlay contract. The consequence is linked to tracker.draft.c4e3c99fe51c321a4a25.

## Editorial and semantic decisions

- Hindi uses CLDR cardinal one / other forms where the counted noun changes, including activity counts. Invariant count nouns retain matching one/other text. Duration helpers include Hindi singular/plural forms for hours; the two-digit minute-format token is retained exactly.
- The accepted base uses फ़ोकस for the Focus state label and तकनीकी इंटरफ़ेस for the technical shell; this supplement follows that terminology. Room is retained.
- Safe static error copy does not expose raw exception class/message payloads where the resolved source recipe marks them diagnostic-only. Stable typed argument definitions remain verbatim in the source fields.
- The existing semantic-context caution about “all data only on this phone” and user-selected exports is not changed by this supplement and still needs shared source/data-flow resolution before release.
- The CSV unit tracker.draft.d7bacc8fa4bed5ab16cb remains blocked because its row-summary/error/warning payload lacks a complete translator-safe contract; both source occurrence IDs and the blocked source contract are preserved.

## Validation

Pure data checks confirmed exact 49-key / 103-occurrence coverage, with 48 ready recipes / 101 occurrences translated and one blocked CSV recipe / 2 occurrences left untranslated. Every occurrence ID is present exactly once. Source Russian objects, recipes, typed arguments, evidence, conditions, statuses, correction provenance, and source-record hashes match the accepted resolution package. All aligned translated branches retain their placeholder token multisets; Hindi one/other forms preserve matching placeholders. All four restore flag assignments, the single combined warning, linked consequence, and verified-only Room suffix were checked. The accepted base package SHA remained unchanged.

No application, Pages, or source code was touched, and no build, runtime, or device validation was performed. Native Hindi editorial and UI-fit review is still recommended.

## Independent composition review correction

- `tracker.draft.5c180296093f2175e7c5`, Hindi calendar-page issue variants: added terminal danda to each of the four localized status fragments (`बंद है`, `पहुंच की अनुमति नहीं है`, `अभी उपलब्ध नहीं है`, `अमान्य इवेंट प्राप्त हुआ`). The resolved source recipe gives each corresponding Russian fragment a full stop, and the fixed template continues with “История не изменена”; the punctuation keeps the two sentences separate in the rendered Hindi message. This edit changes only the Hindi composition recipe, not the preserved source/conditions.
- Revalidated exact 49-key / 103-occurrence coverage, all copied source/recipe/evidence fields, typed arguments and stable error IDs, blocked CSV null payload, overlay hashes/contracts, and accepted-base SHA after the edit.
