# Hindi UI translation draft — Tracker

- Target locale: `hi-IN` (Hindi, India).
- Source manifest: `translation-units.json`.
- Source manifest SHA-256: `285e196dac220a2d3e95ffed48034bc04713d7e29995d8b8aedf7cb3e4cf6324`.
- Coverage: all 376 `ready_for_translation` units and all 402 ready variants are translated; 25 conditional units cover 51 variants.
- Remainder: 49 `needs_composition` units and 5 `non_translatable` units remain explicitly listed and untranslated.
- Preservation: exact source text, conditions, SHA-256 values, placeholders, and occurrence IDs are retained for translated variants. Deferred source units also carry the manifest's source occurrence IDs; 563 unique IDs across the complete package match the source manifest exactly.
- Validation: unique key coverage and source order checked; 402/402 exact source-text hashes and placeholder-token multisets pass; no invisible Unicode format controls were inserted. Full structure, deferred IDs, and conditions were checked against the immutable manifest.
- Context decisions: the undo success toast is `पूर्ववत किया गया` (reversed/undone, not a pending cancellation); canceled exports say prepared files remain available; CSV “append” is rendered as importing/adding records into the app, not appending to the CSV file. Dynamic phase labels use wording that avoids grammatical agreement with `$phase`; both phase-label branches are included.
- Protected values and identifiers: runtime placeholders, IDs, brand names, filenames, license names, and technical codes are retained as supplied. User/catalog values inside placeholders are not translated.
- Semantic correction history: an index-offset error in my manual edit affected flattened variants 14–16 (zero-based): `Оставить без занятия`, `Завершение интервала Focus`, and `Focus: интервал завершён`. This specific reassignment was corrected against exact draft keys, conditions, source texts, hashes, and prior Hindi values. The full set of verified manual corrections is recorded in `review_corrections`.
- Release review: source unit `tracker.draft.5027e9837e3ca3339a41` says all data is stored only on the phone, while the semantic context notes that user-selected exports may go to external/cloud locations. This locale preserves the exact source copy; resolve the source wording/data-flow review for all locales before release.
- Status: editorial draft for native Hindi and UI-fit review, not a claim of shipped locale support. No app, runtime, build, tests, repository, or Pages were changed or exercised.
