# Traduzione italiana di Tracker — bozza editoriale

- Manifesto sorgente: `translation-units.json`.
- SHA-256 del manifesto sorgente: `285e196dac220a2d3e95ffed48034bc04713d7e29995d8b8aedf7cb3e4cf6324`.
- Lingua di destinazione: italiano (`it`), con tono d’interfaccia uniforme, diretto e informale.
- Stato: **bozza da far rivedere a una persona madrelingua e da verificare nell’interfaccia**; non pronta per la produzione.
- Copertura: 376/376 unità `ready_for_translation` e 402/402 varianti tradotte. Le 25 unità condizionali e le loro 51 varianti conservano le condizioni originali.
- Occorrenze delle unità pronte: 437/437 coperte esattamente una volta. ID delle occorrenze, condizioni, testi sorgente, token dei segnaposto e hash dei testi sorgente sono rimasti invariati.
- Elementi lasciati fuori dalla traduzione: 49 unità `needs_composition` e 5 unità `non_translatable`, mantenute in due gruppi distinti con stato e contenuto sorgente intatti. Non sono state inventate formulazioni mancanti.
- Verifiche statiche superate: chiavi e ordine previsti, copertura di unità/varianti/occorrenze, conservazione dei rami condizionali, corrispondenza dei segnaposto e SHA-256 dei 402 testi sorgente in UTF-8. L’hash del manifesto corrisponde al valore atteso.
- Scelte terminologiche: `attività` per le attività tracciate, `registrazione` per gli elementi della cronologia, `intervallo` per i segmenti temporali, `scheda` per le schede modificabili del catalogo, `fuso orario dei report` per il fuso usato nei report. Le stringhe mantengono esplicite le conseguenze di orari sconosciuti, ripristino e sostituzione, annullamento, importazione ed esportazione. Restano invariati marchi, nomi inseriti dagli utenti, identificatori, esempi di fusi/formati e codici di comando `Start` e `Switch`.
- Correzione contestuale: `tracker.draft.d1addc4a5f6d758c11c5` è reso `Modifica annullata`, perché il chiamante `rt.tracker.undo(token)` segnala un annullamento già eseguito, non un’operazione cancellata. La stringa sorgente e i dati sorgente non sono stati modificati; la correzione non è stata verificata a runtime.
- Revisione consigliata: naturalezza e coerenza terminologica, troncamento nelle superfici Android, accessibilità, leggibilità degli avvisi e resa dei valori dinamici.
- Controllo limitato ai dati: non sono stati avviati l’applicazione, build o test, né è stato effettuato un controllo visivo dell’interfaccia. Questo lotto non equivale a un’applicazione completamente localizzata.
