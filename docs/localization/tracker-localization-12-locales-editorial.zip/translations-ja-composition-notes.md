# Japanese composition supplement — editorial notes

Status: completed Japanese editorial composition draft for 48 ready static recipes / 101 occurrences. The single CSV import-preview unit remains blocked (2 occurrences) with no partial translation. All entries remain integration-pending; this file does not claim the application has Japanese runtime resources or has passed build/device QA.

## Inputs and integrity

- translation-units.json — SHA-256 285e196dac220a2d3e95ffed48034bc04713d7e29995d8b8aedf7cb3e4cf6324
- composition-resolution.json — SHA-256 af2648725aeab5817ab872a058149dcd55954e179db25c6e40d9a2e59616cfab
- composition-correction-overlay.json — SHA-256 6aee8e082c14f079d2b6e83de231bbbc92e6a096724deed10894ccf962b1a240
- translation-semantic-context.json — SHA-256 cf35e1042130b9c228f687427df14a9bb110a7fe0359000a7e6e74c75a1ee72b
- translation-review-ja-ko-hi.json — SHA-256 12364869c542b42d5cd95bcb59bfcc169fef7fe806fbaa2e95d4f3790b4ca4cc
- Accepted base translations-ja.json and translations-ja-notes.md were reviewed. Base SHA-256 remains 7202dc244527134300b1459c52cef42dba780df1e98bad41fa27681b4f0c452f.
- Final translations-ja-composition.json after independent semantic review — SHA-256 f1d754838b5b6a5642ce576ac1c8003f1866f8f277fcac9433ac42adcef51d3a

## Overlay corrections

The original Russian source object, baseline resolved recipe, typed arguments, evidence, source hashes, and occurrence IDs are preserved exactly. The source correction overlay and per-unit composition_correction_provenance retain the prior values and corrected contract separately.

- tracker.draft.f4e3d7be631be3107e29: use 技術シェル{roomSchemaSuffix}. The suffix is exactly “ · Room {roomSchemaVersion}” only when verified metadata from the exact final target build is available; it is empty when missing or unverified. No fixed Room 5, Room 6, or JSON 8 is asserted. Final-SHA rebase and metadata verification remain required before integration.
- tracker.draft.1a4d6d93d1b328fa3369: the replacement template reuses {consequence} once and selects one {unfinishedDataSentence} for the four unfinishedTail / unfinishedFocus combinations. The two-true case is one combined warning with one unknown-time consequence, and asks the user to clarify both affected times. {segments} is the preview segment count (preview.segments), as mapped by the preserved overlay contract. The consequence is linked to tracker.draft.c4e3c99fe51c321a4a25.

## Editorial and semantic decisions

- Japanese uses CLDR other for count phrases. Source conditions, enum/wire values, IDs, dynamic arguments, codes, and user/catalog content are retained as specified by the source contracts.
- Product label Focus is kept in line with the accepted Japanese base. 技術シェル follows the existing base wording for the technical shell; Room is retained.
- Safe static error copy does not expose raw exception class/message payloads where the resolved source recipe marks them diagnostic-only. Stable typed argument definitions remain verbatim in the source fields.
- The existing semantic-context caution about “all data only on this phone” and user-selected exports is not changed by this supplement and still needs shared source/data-flow resolution before release.
- The CSV unit tracker.draft.d7bacc8fa4bed5ab16cb remains blocked because its row-summary/error/warning payload lacks a complete translator-safe contract; both source occurrence IDs and the blocked source contract are preserved.

## Validation

Pure data checks confirmed exact 49-key / 103-occurrence coverage, with 48 ready recipes / 101 occurrences translated and one blocked CSV recipe / 2 occurrences left untranslated. Every occurrence ID is present exactly once. Source Russian objects, recipes, typed arguments, evidence, conditions, statuses, correction provenance, and source-record hashes match the accepted resolution package. All aligned translated branches retain their placeholder token multisets; all four restore flag assignments, the single combined warning, linked consequence, and verified-only Room suffix were checked. The accepted base package SHA remained unchanged.

No application, Pages, or source code was touched, and no build, runtime, or device validation was performed. Native Japanese editorial and UI-fit review is still recommended.

## Independent semantic review corrections

- `tracker.draft.8f81b162870e4a56abe0` (FocusMode.RECOVERY, `UI-fb60e258-5b05e6-L0038-C048`) and `tracker.draft.1e318cac7a56777b5fd2` (Mode.RECOVERY, `UI-8949ea80-2c2906-L0505-C164`): `時間の調整が必要です` → `時間の確認が必要です`. Russian source says time needs clarification; 調整 could imply changing a known time. This follows the accepted base terminology.
- `tracker.draft.feb3e0d3abc27a82dcfb`: `新しい記録には使用できません：{availabilityLabel}。` → `新しいアクティビティには使用できません：{availabilityLabel}。`. Source says unavailable for a new activity; 記録 incorrectly narrows this to a saved record.
- `tracker.draft.732c387a55591a641041`, both deletion branches: `削除直後であれば取り消せます。` → `削除直後であれば元に戻せます。`. The source and destructive-confirmation contract promise undo of a completed deletion, not cancelling a pending action.
- `tracker.draft.732c387a55591a641041`, segment detail: `{segmentCountPhrase}（一時停止の間）` → `{segmentCountPhrase}（一時停止の合間）`, matching the source “between pauses,” rather than “during a pause.”
- `tracker.draft.e5a679569db5ff05a9da`, conflict branch: `変更との競合が {conflictCount} 件あります。` → `自分の変更との競合が {conflictCount} 件あります。`, matching source “conflicts with your own changes.”
- `tracker.draft.c8c6f09530d96b112f5c`, missing-version fallback: `catalogVersion: "base"` → `catalogVersion: "基本版"`. The real version remains opaque; only the source fallback “базовая” is localized.

The Japanese semantic pass covered all 48 ready recipes and their branches. The remaining `{errorCode}` value must be mapped from the typed error enum to localized UI copy or kept diagnostic-only at integration; raw `e.code` must not be displayed. CSV remains blocked, exact final-SHA/Room metadata rebasing remains required, and native Japanese UI/layout/device QA remains outstanding.

