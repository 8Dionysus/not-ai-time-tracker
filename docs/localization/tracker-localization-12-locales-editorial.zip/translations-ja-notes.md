# Tracker Japanese translation — prepared slice

- Source manifest: `translation-units.json`
- Source manifest SHA-256: `285e196dac220a2d3e95ffed48034bc04713d7e29995d8b8aedf7cb3e4cf6324`
- Source snapshot: all 24 source-blob hashes are carried into `translations-ja.json`.
- Target locale: `ja` (Japanese). Status: **complete editorial draft for native-language and UI review**, not a production-readiness claim or evidence that the app supports this locale.
- Coverage: all 376/376 `ready_for_translation` units and 402/402 source-text variants are translated; this includes 25 conditional units with 51 branches. No ready unit is blocked.
- Left untranslated exactly as scoped: 49 `needs_composition` and 5 `non_translatable` units (54 total); their source and status are retained.
- Occurrence IDs: all 563/563 IDs are preserved and assigned exactly once (437 in ready units; 126 in the untranslated remainder).
- Validation: exact ready-key coverage/order and uniqueness, all 402 source-text SHA-256 values, variant conditions and occurrence IDs, exact placeholder tokens, and complete occurrence-ID coverage passed. The untranslated remainder was retained from the source-based English draft unchanged.
- Editorial conventions: `(not)AI`, `Focus`, technical action labels `Start` and `Switch`, code-like terms/identifiers such as `ID`, `target`, `duration`, `namespace`, `Decimal`, `CSV`, `JSON`, `ISO-8601`, IANA zone IDs, `DB/WAL/SHM`, and named services/fonts are kept identifiable. Dynamic placeholders are unchanged. User-authored/catalog activity names remain dynamic content and are not translated.
- Semantic context: the toast for `rt.tracker.undo(token)` says the action was restored/undone (`操作を元に戻しました`), not that an operation was cancelled. The cancelled-export message says prepared files are retained and a new copy can be prepared; it does not claim a new export succeeded. The CSV progress label explicitly says rows are added from CSV into the app. Existing cancel/abort actions remain distinct from successful undo.
- Source-copy caution: the supplied source says data is stored only on this phone. This draft translates that source faithfully; the separate proposed clarification about user-selected exports remains unapplied and should be reconciled against exact release behavior before release.
- Suggested review: native Japanese editorial review; terminology and short-label consistency; truncation, accessibility strings, placeholder rendering, and layout on target devices. This is a static data pass only; no build, tests, app launch, runtime/notification rendering, or device-locale QA was performed.
- Scope: only `translations-ja.json` and these notes were created. No application/runtime files, Pages, source manifest, or permissions were changed; no new agents were launched.

## Проверка следа источника
15 октября: независимый review обнаружил отсутствие source_occurrence_ids в 54 deferred units. Координатор добавил их из неизменяемого манифеста; теперь все 563 IDs действительно присутствуют ровно по одному разу. Переводы и исходные тексты не менялись. Прежнее утверждение полноты до этой поправки было неточным.
