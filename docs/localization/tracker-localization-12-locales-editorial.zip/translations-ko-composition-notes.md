# Korean composition supplement — editorial notes

Status: completed Korean editorial composition draft for 48 ready static recipes / 101 occurrences. The single CSV import-preview unit remains blocked (2 occurrences) with no partial translation. All entries remain integration-pending; this file does not claim the application has Korean runtime resources or has passed build/device QA.

## Inputs and integrity

- translation-units.json — SHA-256 285e196dac220a2d3e95ffed48034bc04713d7e29995d8b8aedf7cb3e4cf6324
- composition-resolution.json — SHA-256 af2648725aeab5817ab872a058149dcd55954e179db25c6e40d9a2e59616cfab
- composition-correction-overlay.json — SHA-256 6aee8e082c14f079d2b6e83de231bbbc92e6a096724deed10894ccf962b1a240
- translation-semantic-context.json — SHA-256 cf35e1042130b9c228f687427df14a9bb110a7fe0359000a7e6e74c75a1ee72b
- translation-review-ja-ko-hi.json — SHA-256 12364869c542b42d5cd95bcb59bfcc169fef7fe806fbaa2e95d4f3790b4ca4cc
- Accepted base translations-ko.json and translations-ko-notes.md were reviewed. Base SHA-256 remains 66422a760c5c8fe9e341c4b7414ab69c736ab57b7c3c8bf2ea01fb93ee8801c2.
- Final translations-ko-composition.json after independent semantic review — SHA-256 e197d262c81d1b9a23e794e25d456e94bc55926a85015d2ff672e1e8e903adeb

## Overlay corrections

The original Russian source object, baseline resolved recipe, typed arguments, evidence, source hashes, and occurrence IDs are preserved exactly. The source correction overlay and per-unit composition_correction_provenance retain the prior values and corrected contract separately.

- tracker.draft.f4e3d7be631be3107e29: use 기술 화면{roomSchemaSuffix}. The suffix is exactly “ · Room {roomSchemaVersion}” only when verified metadata from the exact final target build is available; it is empty when missing or unverified. No fixed Room 5, Room 6, or JSON 8 is asserted. Final-SHA rebase and metadata verification remain required before integration.
- tracker.draft.1a4d6d93d1b328fa3369: the replacement template reuses {consequence} once and selects one {unfinishedDataSentence} for the four unfinishedTail / unfinishedFocus combinations. The two-true case is one combined warning with one unknown-time consequence, and asks the user to enter both affected times. {segments} is the preview segment count (preview.segments), as mapped by the preserved overlay contract. The consequence is linked to tracker.draft.c4e3c99fe51c321a4a25.

## Editorial and semantic decisions

- Korean uses CLDR other for count phrases. Source conditions, enum/wire values, IDs, dynamic arguments, codes, and user/catalog content are retained as specified by the source contracts.
- The accepted base uses 집중 for the Focus state label and 기술 화면 for the technical shell; this supplement follows that terminology. Room is retained.
- Safe static error copy does not expose raw exception class/message payloads where the resolved source recipe marks them diagnostic-only. Stable typed argument definitions remain verbatim in the source fields.
- The existing semantic-context caution about “all data only on this phone” and user-selected exports is not changed by this supplement and still needs shared source/data-flow resolution before release.
- The CSV unit tracker.draft.d7bacc8fa4bed5ab16cb remains blocked because its row-summary/error/warning payload lacks a complete translator-safe contract; both source occurrence IDs and the blocked source contract are preserved.

## Validation

Pure data checks confirmed exact 49-key / 103-occurrence coverage, with 48 ready recipes / 101 occurrences translated and one blocked CSV recipe / 2 occurrences left untranslated. Every occurrence ID is present exactly once. Source Russian objects, recipes, typed arguments, evidence, conditions, statuses, correction provenance, and source-record hashes match the accepted resolution package. All aligned translated branches retain their placeholder token multisets; all four restore flag assignments, the single combined warning, linked consequence, and verified-only Room suffix were checked. The accepted base package SHA remained unchanged.

No application, Pages, or source code was touched, and no build, runtime, or device validation was performed. Native Korean editorial and UI-fit review is still recommended.

## Independent semantic review corrections

- `tracker.draft.feb3e0d3abc27a82dcfb`: `새 기록에는 사용할 수 없습니다` → `새 활동에는 사용할 수 없습니다`. The resolved `ChoiceAvailability` recipe is “Недоступно для нового занятия”; the accepted Korean base uses `활동` for the activity concept, while `기록` means a saved record.
- `tracker.draft.732c387a55591a641041`, both deletion-confirmation variants: `삭제 직후에는 취소할 수 있습니다.` → `삭제 직후에는 실행 취소할 수 있습니다.` The source/contract promises undo after a completed deletion; explicit undo wording distinguishes it from cancellation of a pending operation.
- `tracker.draft.8b4e4ed2b5d4ff15bfbc`, single-item starter branch: `“{starterTitle}”을(를) 한 번 탭해 시작할 수 있습니다.` → `한 번 탭하면 바로 시작할 수 있는 활동: “{starterTitle}”`. This removes a visible alternative-particle placeholder while preserving the one-tap start meaning and the exact user/catalog title.

The Korean semantic pass covered all 48 ready recipes and their branches. CSV remains blocked; native-language UI-fit and runtime/device QA remain outstanding.
