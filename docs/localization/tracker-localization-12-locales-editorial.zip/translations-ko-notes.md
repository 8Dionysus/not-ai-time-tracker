# Korean UI Tracker editorial translation

- Target locale: `ko` (Korean)
- Source locale: Russian (`ru`)
- Input manifest SHA-256: `285e196dac220a2d3e95ffed48034bc04713d7e29995d8b8aedf7cb3e4cf6324`
- Source snapshot: copied without modification from the verified prepared translation package
- Scope: all 376 `ready_for_translation` units and 402 ready variants, including all 25 conditional units / 51 conditional variants
- Explicit remainder: 49 `needs_composition` units and 5 `non_translatable` units remain untranslated in `translations-ko.json` with source status, source content, and reason retained

## Editorial choices

- Used concise, polite Korean appropriate for Android controls and messages. Action buttons are short; explanatory and consequence-bearing messages use clear complete sentences.
- Preserved brand names, technical identifiers, formatter/code placeholders, catalog or user-provided dynamic values, and numeric ranges exactly. Dynamic values are not translated.
- Used distinct wording for undo and cancellation. The successful `rt.tracker.undo(token)` message is “실행한 작업을 되돌렸습니다.” Pending operations use “취소” / “취소되었습니다.”
- Export cancellation text states that the prepared files remain available; it does not say a new destination copy was saved.
- CSV append/import is phrased as adding records to the app, not appending rows to the CSV file.
- Restore/full-replacement, rollback-copy, deletion, unknown-time, and time-zone messages retain their operational consequences and caveats.
- The source string claiming all data is stored only on the phone is translated faithfully because this packet retains immutable source text. The supplied semantic context flags that statement for source-copy review: exports can go to a user-selected external/cloud destination. No source correction or application change was made in this translation pass.

## Validation

- 376 / 376 ready keys translated in source order; no missing, extra, or duplicate keys
- 402 / 402 variant translations present; conditions and variant order retained
- All 563 source occurrence IDs across ready and deferred/preserved units are assigned exactly once
- All 402 exact source strings and SHA-256 source-text hashes retained and verified
- Placeholder tokens match exactly in all 402 variants; no extra interpolation/code token was introduced
- Remainder remains explicit: 49 `needs_composition`, 5 `non_translatable`
- Local-data editorial work only; no app build, runtime/device QA, application editing, Pages, or external localization service used

## Release note

This is a complete editorial draft for the ready slice, not a fully localized or runtime-validated application. A native Korean linguistic/UI review is still recommended, particularly for compact overlay/notification widths and the source-copy issue noted above.
