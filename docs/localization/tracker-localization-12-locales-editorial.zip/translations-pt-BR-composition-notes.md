# Tracker composition copy — Portuguese (Brazil) / pt-BR

## Scope and provenance

This is an editorial, data-only pt-BR draft for the Tracker composition units. pt-BR is explicitly Brazilian Portuguese; it is not presented as universal Portuguese or proof of locale/runtime support. No application code, UI, runtime, build, tests, or device state were edited or checked. The base UI package `translations-pt-BR.json` was left unchanged.

| Input | SHA-256 |
|---|---|
| `translation-units.json` | `285e196dac220a2d3e95ffed48034bc04713d7e29995d8b8aedf7cb3e4cf6324` |
| `composition-resolution.json` | `af2648725aeab5817ab872a058149dcd55954e179db25c6e40d9a2e59616cfab` |
| `composition-correction-overlay.json` | `6aee8e082c14f079d2b6e83de231bbbc92e6a096724deed10894ccf962b1a240` |
| EN composition reference | `f7fe3022ff9ff3dc6ebcb39280d99ed07b6a6352c01b4c4d1399d68b562db413` |
| ES composition reference | `e35b48c8d0f8dd9ee049b979e1885994b1cbaed6601032338240be1d7a414c48` |

The overlay records its review-baseline SHA `0d2de72d6f8854008430d974b68acc17fdb32753650c7035b88fe55bca355d76`. The append-only review file now present is later context and is not substituted for the overlay’s historical input. The overlay correction is used as the mandatory replacement contract for its two parent keys. Each ready record in the JSON keeps exact Russian `source_ru_exact`, source occurrence IDs, canonical source-record and exact-source hashes, and the original resolved recipe. For corrected keys the complete overlay replacement contract is separately retained with its own hash and provenance; the baseline recipe is explicitly marked as not used for the pt-BR translation.

## Coverage and state

- Ready composition units translated: 48 / 48.
- Occurrences in those ready units: 101 / 101.
- Blocked CSV unit: 1 key, 2 occurrences; carried with exact source and reason, with no pt-BR text proposed.
- All ready parent keys, source conditions, source occurrence IDs, source texts, and canonical source hashes were checked against the immutable source files.
- The fixed input hashes above and required overlay hash were rechecked.

The JSON is an editorial draft only. The composition resolution says integration is pending. Before integration, rebase against the exact final target commit and verify typed arguments, enum/source mappings, and relevant producers at that SHA. No final Sol SHA is supplied. Do not claim target-build validation.

## Corrected overlay contracts

### `tracker.draft.f4e3d7be631be3107e29` — technical diagnostic panel

The exact Russian source remains unchanged in `source_ru_exact` (including the literal `Room 5`). The original resolved recipe and its hash are retained separately and marked not used for this translation. The replacement contract and translation use an optional `{roomSchemaSuffix}`: only show ` · Room {roomSchemaVersion}` when the exact final target build’s Room `@Database` schema metadata is SHA-verified; otherwise emit an empty suffix. Never infer Room schema version from JSON backup format metadata. No Room 5, Room 6, or JSON 8 value is hard-coded in the proposed pt-BR title. The JSON keeps the overlay’s entire replacement contract and replacement hash.

### `tracker.draft.1a4d6d93d1b328fa3369` — restore preview and one warning slot

The exact Russian source and pre-correction recipe are both preserved separately. The corrected contract maps `{segments}` only to `preview.segments` (never `preview.cards`), uses `{consequence}` from existing localized unit `tracker.draft.c4e3c99fe51c321a4a25` exactly once, and selects one sentence slot using both unfinished-data flags together. Portuguese branch behavior was checked for all four cases:

| unfinishedTail | unfinishedFocus | warning sentence count | unknown-time consequence count |
|---:|---:|---:|---:|
| false | false | 0 | 0 |
| true | false | 1 | 1 |
| false | true | 1 | 1 |
| true | true | 1 | 1 |

The both-true case is one combined pt-BR warning; tail and Focus warnings are never concatenated. Each present branch contains one sentence, mentions the time as unknown once, and says that it must be clarified. Count values and source semantics remain unchanged.

## Locale conventions

- Plurals: pt-BR CLDR `one` only for exactly 1, and `other` for 0 and all other counts. Target plural groups keep the numeric count and provide both forms.
- Durations: use locale presentation of canonical milliseconds. In the dedicated formatter, values `<= 0` render as `0 min`; positive durations under 60 seconds use `max(1, floor(durationMs / 1000))` seconds; whole hours use hours; hour-plus-minute output zero-pads the minute remainder to two digits; remaining durations use minutes. Do not recompute elapsed durations from timestamps.
- Localized presentation may change dates, numbers, lists, byte sizes, or time strings only. Do not change canonical quantities, milliseconds, instants, count semantics, order, IDs, IANA zone identifiers, enum/wire values, version identifiers, or user/catalog text.
- Product/technical names retained as names include `Focus`, `CSV`, `JSON`, `Room`, `IANA`, `ISO-8601`, and `DB/WAL/SHM`. User-entered names and catalog values are arguments, not translation copy. Exception message/class details remain diagnostic-only unless represented by a safe typed reason.

## Exhaustive branch, plural, and format ledger

The following per-unit JSON blocks are the proposed pt-BR copy contracts. They list every translated branch/condition, plural form, and applicable formatting rule in the same structure used by `translations-pt-BR-composition.json`. Exact Russian source, exact source recipe/conditions, and source occurrence IDs remain in that JSON beside each block.

### `tracker.draft.765c7dfb452f1e326531`

Occurrences: UI-9eb89e6c-cf8364-L0067-C051. Source status: `translation_ready_but_integration_pending`.

```json
{
  "template": "Não foi possível ler o formulário salvo.",
  "intentional_omissions": [
    "O tipo da exceção permanece apenas em diagnóstico; não exibir ${e.javaClass.simpleName} no texto traduzido."
  ]
}
```

### `tracker.draft.19e098a209f2fde110ce`

Occurrences: UI-9eb89e6c-cf8364-L0077-C049. Source status: `translation_ready_but_integration_pending`.

```json
{
  "template": "O banco de dados local está indisponível. Os arquivos originais foram preservados. Escolha uma cópia na seção de restauração.",
  "intentional_omissions": [
    "Detalhes brutos de ${e.message} ficam apenas em diagnóstico; não anexá-los à mensagem visível."
  ]
}
```

### `tracker.draft.62267ac133c73f84a2d4`

Occurrences: UI-9eb89e6c-cf8364-L0127-C206. Source status: `translation_ready_but_integration_pending`.

```json
{
  "template": "Não foi possível repetir o registro: não há histórico concluído.",
  "error_key": "tracker.error.repeat_no_completed_history",
  "error_code": "INVALID_INPUT"
}
```

### `tracker.draft.2e4f5c5cb3b30835fde6`

Occurrences: UI-9eb89e6c-cf8364-L0128-C112. Source status: `translation_ready_but_integration_pending`.

```json
{
  "template": "Sem especificação",
  "use": "fallback localizado de exibição quando um favorito não tem nome; não salvar essa tradução como conteúdo do catálogo."
}
```

### `tracker.draft.f5e54f05bac32427ef1c`

Occurrences: UI-9eb89e6c-cf8364-L0133-C033. Source status: `translation_ready_but_integration_pending`.

```json
{
  "variants": [
    {
      "when": "AVAILABLE",
      "translation_pt_BR": "Disponível"
    },
    {
      "when": "ARCHIVED_CARD",
      "translation_pt_BR": "A atividade está arquivada"
    },
    {
      "when": "ARCHIVED_TYPE",
      "translation_pt_BR": "O tipo de atividade está arquivado"
    },
    {
      "when": "GROUP",
      "translation_pt_BR": "É um grupo de atividades e não pode ser iniciado diretamente"
    },
    {
      "when": "EMPTY_GROUP",
      "translation_pt_BR": "Este grupo ainda não tem atividades disponíveis"
    }
  ],
  "template": "{entryTitle} · {sourceId}\n{availabilityMessage}. O favorito usa os parâmetros salvos, inclusive os arquivados.",
  "preserve": [
    "entryTitle",
    "sourceId"
  ]
}
```

### `tracker.draft.22dfef5eb28ed461ac5a`

Occurrences: UI-9eb89e6c-cf8364-L0143-C183. Source status: `translation_ready_but_integration_pending`.

```json
{
  "template": "Não foi possível corrigir o segmento: não há segmento registrado e encerrado.",
  "error_key": "tracker.error.correct_no_closed_segment",
  "error_code": "INVALID_INPUT"
}
```

### `tracker.draft.feb3e0d3abc27a82dcfb`

Occurrences: UI-9eb89e6c-cf8364-L0185-C049. Source status: `translation_ready_but_integration_pending`.

```json
{
  "variants": [
    {
      "when": "ARCHIVED_CARD",
      "translation_pt_BR": "a atividade está arquivada"
    },
    {
      "when": "ARCHIVED_TYPE",
      "translation_pt_BR": "o tipo de atividade está arquivado"
    },
    {
      "when": "GROUP",
      "translation_pt_BR": "é um grupo de atividades e não pode ser iniciado diretamente"
    },
    {
      "when": "EMPTY_GROUP",
      "translation_pt_BR": "este grupo ainda não tem atividades disponíveis"
    }
  ],
  "template": "Indisponível para uma nova atividade: {availabilityLabel}."
}
```

### `tracker.draft.64f9fb5e1de0e87d5ef2`

Occurrences: UI-9eb89e6c-cf8364-L0219-C052. Source status: `translation_ready_but_integration_pending`.

```json
{
  "template": "Não foi possível salvar as alterações. Corrija o formulário ou cancele-o.",
  "intentional_omissions": [
    "O conteúdo de ${it.message} é dinâmico e não é incluído como texto de interface."
  ]
}
```

### `tracker.draft.5c180296093f2175e7c5`

Occurrences: UI-9eb89e6c-cf8364-L0315-C052. Source status: `translation_ready_but_integration_pending`.

```json
{
  "variants": [
    {
      "when": "CalendarReadIssue.DISABLED",
      "translation_pt_BR": "desativado."
    },
    {
      "when": "CalendarReadIssue.PERMISSION_REQUIRED",
      "translation_pt_BR": "sem permissão."
    },
    {
      "when": "CalendarReadIssue.PROVIDER_UNAVAILABLE",
      "translation_pt_BR": "indisponível no momento."
    },
    {
      "when": "CalendarReadIssue.INVALID_OCCURRENCE",
      "translation_pt_BR": "foram recebidos eventos inválidos."
    }
  ],
  "template": "Calendário: {calendarIssueMessage} O histórico não foi alterado."
}
```

### `tracker.draft.d27f39ab16fe4f59b925`

Occurrences: UI-9eb89e6c-cf8364-L0321-C103. Source status: `translation_ready_but_integration_pending`.

```json
{
  "variants": [
    {
      "when": "CalendarReadIssue.DISABLED",
      "translation_pt_BR": "O calendário está desativado."
    },
    {
      "when": "CalendarReadIssue.PERMISSION_REQUIRED",
      "translation_pt_BR": "Não há acesso ao calendário."
    },
    {
      "when": "CalendarReadIssue.NOT_FOUND",
      "translation_pt_BR": "O evento do calendário não foi encontrado."
    },
    {
      "when": "CalendarReadIssue.PROVIDER_UNAVAILABLE",
      "translation_pt_BR": "O calendário está indisponível no momento."
    },
    {
      "when": "CalendarReadIssue.INVALID_OCCURRENCE",
      "translation_pt_BR": "O evento do calendário mudou ou está indisponível."
    }
  ],
  "error_key": "tracker.calendar.read_selected_issue"
}
```

### `tracker.draft.c9272236a55890917584`

Occurrences: UI-9eb89e6c-cf8364-L0375-C034. Source status: `translation_ready_but_integration_pending`.

```json
{
  "variants": [
    {
      "when": "settings.notification == false",
      "translation_pt_BR": "desativada"
    },
    {
      "when": "settings.notification == true && notificationsAllowed == true",
      "translation_pt_BR": "permitida"
    },
    {
      "when": "settings.notification == true && notificationsAllowed == false",
      "translation_pt_BR": "solicitada, mas bloqueada pelo sistema ou pelo canal"
    }
  ],
  "template": "Notificação: {notificationPermissionState}\n{overlayStatus}",
  "overlayStatus_rule": "O estado/explicação da sobreposição é um argumento tipado produzido separadamente; conservar como componente localizado e não inventar aqui valores que o contrato de origem não enumera."
}
```

### `tracker.draft.da1416dccbb997370865`

Occurrences: UI-9eb89e6c-cf8364-L0391-C047. Source status: `translation_ready_but_integration_pending`.

```json
{
  "template": "Não foi possível salvar o formulário.",
  "intentional_omissions": [
    "Nome da classe e mensagem da exceção são detalhes de diagnóstico, não texto de interface."
  ]
}
```

### `tracker.draft.df25a20804b6c982ca67`

Occurrences: UI-9eb89e6c-cf8364-L0446-C021, UI-9eb89e6c-cf8364-L0446-C319. Source status: `translation_ready_but_integration_pending`.

```json
{
  "template": "Resumo de {asOfDateTime} ({reportZone}): {recordedDuration}; intervalos com horário desconhecido: {unresolvedCount}\nAtividades: {cardNames}\nSessões: {sessionCount}; segmentos: {segmentCount}\n{rows}",
  "row_format": "{selectionNameOrFallback}: {duration}",
  "row_fallback": "Sem especificação",
  "list_format": "Use a formatação de lista do pt-BR; mantenha exatamente a ordem, os nomes de usuário/catálogo e IDs. Formate duração a partir dos milissegundos; preserve o fuso IANA como dado."
}
```

### `tracker.draft.f4e3d7be631be3107e29`

Occurrences: UI-9eb89e6c-cf8364-L0462-C035. Source status: `translation_ready_but_integration_pending`.

```json
{
  "template": "Painel técnico{roomSchemaSuffix}\n{timerStatus}\n{trustedDuration}\nRevisão {revision}\n{focusStatus}{selection}\n{report}",
  "roomSchemaSuffix_variants": {
    "verified_present": " · Room {roomSchemaVersion}",
    "absent_or_unverified": ""
  },
  "linked_state_recipes": {
    "timerStatus": "tracker.draft.1e318cac7a56777b5fd2",
    "focusStatus": "tracker.draft.8f81b162870e4a56abe0",
    "report": "tracker.draft.df25a20804b6c982ca67",
    "selectionFallback": "tracker.draft.83a4e62d2526d49dcc2d"
  },
  "metadata_contract_pt_BR": "Obtenha roomSchemaVersion somente dos metadados Room verificados do build-alvo exato, vinculado ao SHA final. Se estiver ausente ou não verificado, deixe roomSchemaSuffix vazio. Não use nem infira a versão do formato de backup JSON; não fixe Room 5, Room 6 ou JSON 8.",
  "preserve": [
    "roomSchemaVersion",
    "timerStatus",
    "trustedDuration",
    "revision",
    "focusStatus",
    "selection",
    "report"
  ]
}
```

### `tracker.draft.ff1f02767a4352f91b2f`

Occurrences: UI-9eb89e6c-cf8364-L0477-C097. Source status: `translation_ready_but_integration_pending`.

```json
{
  "template": "Não foi possível iniciar a preparação da exportação.",
  "intentional_omissions": [
    "Detalhe bruto da exceção continua fora da mensagem de interface."
  ]
}
```

### `tracker.draft.1a4d6d93d1b328fa3369`

Occurrences: UI-9eb89e6c-cf8364-L0497-C033. Source status: `translation_ready_but_integration_pending`.

```json
{
  "template": "{consequence}\nSessões: {sessions}; segmentos: {segments}; metas: {goals}.{unfinishedDataSentence}",
  "linked_consequence": "tracker.draft.c4e3c99fe51c321a4a25",
  "canonical_placeholder_mapping": {
    "consequence": "preview.consequence (render once; reuse localized unit tracker.draft.c4e3c99fe51c321a4a25)",
    "sessions": "preview.sessions (count)",
    "segments": "preview.segments (count; never preview.cards)",
    "goals": "preview.goals (count)",
    "unfinishedDataSentence": "one localized sentence slot selected from preview.unfinishedTail and preview.unfinishedFocus together"
  },
  "unfinished_data_cases": [
    {
      "case": "neither",
      "unfinishedTail": false,
      "unfinishedFocus": false,
      "translation_pt_BR": ""
    },
    {
      "case": "tail_only",
      "unfinishedTail": true,
      "unfinishedFocus": false,
      "translation_pt_BR": " Na cópia há um intervalo não finalizado; depois da restauração, o horário será marcado como desconhecido e precisará ser esclarecido."
    },
    {
      "case": "focus_only",
      "unfinishedTail": false,
      "unfinishedFocus": true,
      "translation_pt_BR": " Na cópia há um Focus não finalizado; depois da restauração, o horário será marcado como desconhecido e precisará ser esclarecido."
    },
    {
      "case": "both",
      "unfinishedTail": true,
      "unfinishedFocus": true,
      "translation_pt_BR": " A cópia contém um intervalo não finalizado e um Focus não finalizado; depois da restauração, o horário de cada um será marcado como desconhecido e ambos precisarão ser esclarecidos."
    }
  ],
  "truth_table_contract": "Selecione exatamente um unfinishedDataSentence a partir dos dois booleanos; não concatene avisos de cauda e Focus. A consequência localizada é exibida uma única vez. Quantidades e valores de sessão/segmento/meta permanecem inalterados.",
  "preserve": [
    "consequence",
    "sessions",
    "segments",
    "goals"
  ]
}
```

### `tracker.draft.6eb0ae46714a472c7cd1`

Occurrences: UI-9eb89e6c-cf8364-L0532-C031. Source status: `translation_ready_but_integration_pending`.

```json
{
  "variants": [
    {
      "when": "result.verified",
      "translation_pt_BR": "A cópia foi verificada por leitura."
    },
    {
      "when": "!result.verified",
      "translation_pt_BR": "O provedor de armazenamento não permite verificar a cópia por leitura."
    }
  ],
  "template": "Arquivo salvo: {byteCount}. {verificationResult}",
  "format_note": "byteCount é somente formatação localizada de bytes; não alterar o valor nem inferi-lo a partir de outra medida."
}
```

### `tracker.draft.d71e114cdd4d19d93b54`

Occurrences: UI-9eb89e6c-cf8364-L0539-C044. Source status: `translation_ready_but_integration_pending`.

```json
{
  "template": "Não foi possível abrir o arquivo CSV selecionado.",
  "error_key": "tracker.error.csv_source_unavailable"
}
```

### `tracker.draft.3ec2feee7aadaf04f8eb`

Occurrences: UI-9eb89e6c-cf8364-L0542-C139. Source status: `translation_ready_but_integration_pending`.

```json
{
  "template": "Não foi possível abrir o arquivo de backup selecionado.",
  "error_key": "tracker.error.backup_source_unavailable"
}
```

### `tracker.draft.db5dc196ba061092492b`

Occurrences: UI-01435e61-69c738-L0168-C035. Source status: `translation_ready_but_integration_pending`.

```json
{
  "template": "Ocorreu um erro ({errorCode}). Abra o app; o histórico não foi alterado.",
  "note": "errorCode deve ser um código estável permitido para exibição; não inserir a mensagem bruta da exceção."
}
```

### `tracker.draft.22131ffd7c2c07f5582c`

Occurrences: UI-58d940fe-a740d2-L0093-C014. Source status: `translation_ready_but_integration_pending`.

```json
{
  "template": "Os arquivos não foram excluídos. Você pode restaurar o banco de dados ou escolher uma cópia na interface técnica.",
  "intentional_omissions": [
    "Detalhes da falha não são expostos; conservar o aviso de que os arquivos foram mantidos e as duas opções de recuperação."
  ]
}
```

### `tracker.draft.732c387a55591a641041`

Occurrences: UI-58d940fe-a740d2-L0201-C063, UI-58d940fe-a740d2-L0201-C074, UI-58d940fe-a740d2-L0201-C085, UI-58d940fe-a740d2-L0201-C099, UI-58d940fe-a740d2-L0202-C071, UI-58d940fe-a740d2-L0202-C084, UI-58d940fe-a740d2-L0202-C097, UI-58d940fe-a740d2-L0203-C024, UI-58d940fe-a740d2-L0204-C050. Source status: `translation_ready_but_integration_pending`.

```json
{
  "variants": [
    {
      "when": "parts list not empty",
      "translation_pt_BR": "{range}: junto com o registro, serão excluídos {parts}. É possível desfazer logo após a exclusão."
    },
    {
      "when": "parts list empty",
      "translation_pt_BR": "{range}: o registro será excluído. É possível desfazer logo após a exclusão."
    }
  ],
  "parts_joiner": " e ",
  "parts": [
    {
      "when": "r.segments > 1",
      "template": "{segmentCountPhrase} entre pausas",
      "plural_forms": {
        "one": "{count} segmento entre pausas",
        "other": "{count} segmentos entre pausas"
      }
    },
    {
      "when": "r.measurements > 0",
      "template": "{measurementCountPhrase}",
      "plural_forms": {
        "one": "{count} medição",
        "other": "{count} medições"
      }
    }
  ],
  "locale_plural_rule": "pt-BR usa CLDR one para exatamente um e other para zero e todos os demais valores. Junte os itens presentes com a conjunção de lista “ e ”. Mantenha o intervalo registrado; a exclusão só é desfeita se a ação ainda estiver disponível."
}
```

### `tracker.draft.e946acd9bd5d1d0f5bb6`

Occurrences: UI-1dcee2ca-1abd5c-L0038-C053, UI-1dcee2ca-1abd5c-L0129-C033, UI-1dcee2ca-1abd5c-L0134-C018, UI-8eff50b3-bb2c62-L0039-C018. Source status: `translation_ready_but_integration_pending`.

```json
{
  "variants": [
    {
      "when": "title/date-heading context",
      "translation_pt_BR": "Hoje"
    },
    {
      "when": "inline calendar weekday label",
      "translation_pt_BR": "hoje"
    }
  ]
}
```

### `tracker.draft.84def28e711a54b738b5`

Occurrences: UI-1dcee2ca-1abd5c-L0039-C044. Source status: `translation_ready_but_integration_pending`.

```json
{
  "template": "{periodTitle}{incompleteSuffix}",
  "argument_variants": {
    "incompleteSuffix": {
      "when": "d.incomplete == true",
      "true": ", o dia ainda está em andamento",
      "otherwise": ""
    }
  },
  "periodTitle_rule": "Use hoje localizado para DAY; caso contrário, use o intervalo de período formatado para pt-BR."
}
```

### `tracker.draft.ee7e8f3416bf9624e0b4`

Occurrences: UI-1dcee2ca-1abd5c-L0042-C056, UI-8eff50b3-bb2c62-L0040-C031. Source status: `translation_ready_but_integration_pending`.

```json
{
  "variants": [
    {
      "when": "title/date-heading context",
      "translation_pt_BR": "Ontem"
    },
    {
      "when": "inline comparison period",
      "translation_pt_BR": "ontem"
    }
  ]
}
```

### `tracker.draft.5ab73dea2dd25c1e0943`

Occurrences: UI-1dcee2ca-1abd5c-L0045-C033. Source status: `translation_ready_but_integration_pending`.

```json
{
  "template": "{duration} a mais do que {comparisonPeriod}",
  "comparison_period_variants": {
    "DAY": "ontem",
    "other": "no período anterior ({formattedPreviousPeriod})"
  },
  "format_note": "Use a duração absoluta localizada sem alterar o valor; formate o período anterior com as regras pt-BR."
}
```

### `tracker.draft.3af68afd4be62d94fdfc`

Occurrences: UI-1dcee2ca-1abd5c-L0046-C033. Source status: `translation_ready_but_integration_pending`.

```json
{
  "template": "{duration} a menos do que {comparisonPeriod}",
  "comparison_period_variants": {
    "DAY": "ontem",
    "other": "no período anterior ({formattedPreviousPeriod})"
  },
  "format_note": "Use a duração absoluta localizada sem alterar o valor; formate o período anterior com as regras pt-BR."
}
```

### `tracker.draft.093995ec87ba703e45e1`

Occurrences: UI-1dcee2ca-1abd5c-L0047-C029. Source status: `translation_ready_but_integration_pending`.

```json
{
  "template": "O mesmo que {comparisonPeriod}",
  "comparison_period_variants": {
    "DAY": "ontem",
    "other": "no período anterior ({formattedPreviousPeriod})"
  },
  "format_note": "Use a duração absoluta localizada sem alterar o valor; formate o período anterior com as regras pt-BR."
}
```

### `tracker.draft.e33ebe9be67195ae4f22`

Occurrences: UI-1dcee2ca-1abd5c-L0123-C022, UI-8eff50b3-bb2c62-L0022-C030, UI-8eff50b3-bb2c62-L0023-C034, UI-8eff50b3-bb2c62-L0026-C043, UI-8eff50b3-bb2c62-L0026-C060, UI-8eff50b3-bb2c62-L0026-C113. Source status: `translation_ready_but_integration_pending`.

```json
{
  "branches": [
    {
      "when": "durationMs <= 0",
      "translation_pt_BR": "0 min"
    },
    {
      "when": "0 < durationMs < 60_000",
      "translation_pt_BR": "{seconds} s"
    },
    {
      "when": "hours > 0 && minuteRemainder == 0",
      "translation_pt_BR": "{hours} h"
    },
    {
      "when": "hours > 0 && minuteRemainder > 0",
      "translation_pt_BR": "{hours} h {minutes:2-digit} min"
    },
    {
      "when": "otherwise (durationMs >= 60_000 and no full hour)",
      "translation_pt_BR": "{minutes} min"
    }
  ],
  "format_rule": "Formato pt-BR de número e unidades min/s/h. Para duração positiva abaixo de 60 s, seconds = max(1, floor(durationMs/1000)); para horas mais minutos, minutes usa dois dígitos. Mantenha duração canônica em milissegundos, valores e arredondamento; não derive novamente tempos a partir de timestamps."
}
```

### `tracker.draft.e484ca1b0d3bf10979a1`

Occurrences: UI-4b1b159c-c4a72b-L0119-C056, UI-4b1b159c-c4a72b-L0120-C027. Source status: `translation_ready_but_integration_pending`.

```json
{
  "variants": [
    {
      "when": "effective == PickMode.SWITCH",
      "translation_pt_BR": "O registro atual terminará agora, e o novo começará a partir deste minuto."
    },
    {
      "when": "effective == PickMode.LABEL",
      "translation_pt_BR": "O registro em andamento receberá o nome. O início continuará sendo {startClockOrPrevious}."
    }
  ],
  "startClockOrPrevious_fallback": "o horário anterior",
  "format_note": "Se conhecido, startClockOrPrevious é o horário local formatado; caso contrário, use o fallback localizado. Não altere o instante de início."
}
```

### `tracker.draft.78c393343269e6501b4b`

Occurrences: UI-8eff50b3-bb2c62-L0062-C041. Source status: `translation_ready_but_integration_pending`.

```json
{
  "template": "Este arquivo não é compatível: {importReason}",
  "note": "importReason deve vir de um mapeamento de erro seguro/localizado; não injetar Exception.message bruto."
}
```

### `tracker.draft.923e0b844cd0feffdd17`

Occurrences: UI-8eff50b3-bb2c62-L0063-C036. Source status: `translation_ready_but_integration_pending`.

```json
{
  "template": "Não foi possível concluir a ação: {validationReason}",
  "note": "validationReason é uma explicação validada e localizada, não texto de exceção bruto."
}
```

### `tracker.draft.6f18b8c3c50ba0285e7e`

Occurrences: UI-8eff50b3-bb2c62-L0064-C017. Source status: `translation_ready_but_integration_pending`.

```json
{
  "template": "Não foi possível concluir a ação.",
  "intentional_omissions": [
    "e.message e nome de classe da exceção ficam apenas em diagnóstico."
  ]
}
```

### `tracker.draft.29a3a1237d88195c4634`

Occurrences: UI-95f4e02c-13c3d9-L0177-C034, UI-95f4e02c-13c3d9-L0177-C112. Source status: `translation_ready_but_integration_pending`.

```json
{
  "variants": [
    {
      "when": "settings.reportZone != deviceZone",
      "translation_pt_BR": "{selectedZone}. No seu telefone, o fuso atual é {deviceZone}; toque para mudar para ele."
    },
    {
      "when": "settings.reportZone == deviceZone",
      "translation_pt_BR": "{selectedZone}. Este fuso define os limites dos dias no histórico e na visão geral."
    }
  ]
}
```

### `tracker.draft.b74ad19474c15bfb0a4a`

Occurrences: UI-95f4e02c-13c3d9-L0187-C042, UI-95f4e02c-13c3d9-L0188-C046, UI-95f4e02c-13c3d9-L0188-C077. Source status: `translation_ready_but_integration_pending`.

```json
{
  "variants": [
    {
      "when": "last == null",
      "translation_pt_BR": "Ainda não há cópias neste telefone."
    },
    {
      "when": "last != null && verified == false",
      "translation_pt_BR": "Backup mais recente: {dayTitle}, às {clockTime}."
    },
    {
      "when": "last != null && verified == true",
      "translation_pt_BR": "Backup mais recente: {dayTitle}, às {clockTime}; arquivo verificado."
    }
  ]
}
```

### `tracker.draft.eefe53ffeb7ba59a31b9`

Occurrences: UI-95f4e02c-13c3d9-L0190-C065, UI-95f4e02c-13c3d9-L0190-C075, UI-95f4e02c-13c3d9-L0190-C085, UI-95f4e02c-13c3d9-L0190-C133, UI-95f4e02c-13c3d9-L0190-C149, UI-95f4e02c-13c3d9-L0190-C166, UI-95f4e02c-13c3d9-L0191-C068, UI-95f4e02c-13c3d9-L0191-C076, UI-95f4e02c-13c3d9-L0191-C084. Source status: `translation_ready_but_integration_pending`.

```json
{
  "template": "{sessionCountPhrase}, {cardCountPhrase}, {goalCountPhrase}",
  "plural_forms": {
    "sessionCountPhrase": {
      "count": "d.sessions.size",
      "one": "{count} sessão",
      "other": "{count} sessões"
    },
    "cardCountPhrase": {
      "count": "d.cards.size",
      "one": "{count} atividade",
      "other": "{count} atividades"
    },
    "goalCountPhrase": {
      "count": "d.goals.size",
      "one": "{count} meta",
      "other": "{count} metas"
    }
  },
  "locale_plural_rule": "pt-BR CLDR one/other: one somente para 1; other para 0 e quaisquer demais contagens. As quantidades não mudam. O texto russo original, inclusive sua forma editorialmente problemática, fica somente em source_ru_exact."
}
```

### `tracker.draft.c8c6f09530d96b112f5c`

Occurrences: UI-95f4e02c-13c3d9-L0209-C120, UI-95f4e02c-13c3d9-L0209-C172. Source status: `translation_ready_but_integration_pending`.

```json
{
  "template": "{activityCountPhrase}, versão {catalogVersion}. Toque para verificar se há atualização.",
  "plural_forms": {
    "activityCountPhrase": {
      "count": "types",
      "one": "{count} atividade",
      "other": "{count} atividades"
    }
  },
  "fallbacks": {
    "catalogVersion": "base"
  },
  "number_format": "Use agrupamento numérico pt-BR. Preserve exatamente qualquer identificador real de versão; traduza somente o estado sem versão para “base”."
}
```

### `tracker.draft.21e8761d3cd7c48a7965`

Occurrences: UI-95f4e02c-13c3d9-L0225-C013, UI-95f4e02c-13c3d9-L0227-C061, UI-95f4e02c-13c3d9-L0228-C017. Source status: `translation_ready_but_integration_pending`.

```json
{
  "template": "No arquivo há {sessionCountPhrase}, {cardCountPhrase} e {goalCountPhrase}.{unfinishedDataSentence} Os dados atuais serão salvos separadamente antes da substituição. Os registros feitos depois desta cópia serão perdidos.",
  "plural_forms": {
    "sessionCountPhrase": {
      "count": "p.sessions",
      "one": "{count} sessão",
      "other": "{count} sessões"
    },
    "cardCountPhrase": {
      "count": "p.cards",
      "one": "{count} atividade",
      "other": "{count} atividades"
    },
    "goalCountPhrase": {
      "count": "p.goals",
      "one": "{count} meta",
      "other": "{count} metas"
    }
  },
  "argument_variants": {
    "unfinishedDataSentence": {
      "when": "p.unfinishedTail || p.unfinishedFocus",
      "true": " Um registro não finalizado será restaurado com o horário “desconhecido” e precisará ser esclarecido.",
      "otherwise": ""
    }
  },
  "locale_plural_rule": "pt-BR CLDR one/other; one somente para 1, other para 0 e demais valores.",
  "warning_rule": "Preserve o aviso completo sobre horário desconhecido e esclarecimento. Antes da substituição, salvar dados atuais em separado; registros após a cópia serão perdidos. Mantenha consequence/counts no lugar e não suavize a advertência."
}
```

### `tracker.draft.e5a679569db5ff05a9da`

Occurrences: UI-95f4e02c-13c3d9-L0234-C013, UI-95f4e02c-13c3d9-L0235-C048. Source status: `translation_ready_but_integration_pending`.

```json
{
  "variants": [
    {
      "when": "r.conflicts.isEmpty()",
      "translation_pt_BR": "Versão {version}. Novas atividades: {addedCount}; atualizações: {updatedCount}."
    },
    {
      "when": "r.conflicts.isNotEmpty()",
      "translation_pt_BR": "Versão {version}. Novas atividades: {addedCount}; atualizações: {updatedCount}; conflitos com alterações locais: {conflictCount}. Eles precisam ser analisados na interface técnica."
    }
  ],
  "note": "version é identificador opaco; preserve-o. Inclua o segundo aviso somente quando houver conflitos."
}
```

### `tracker.draft.69774bbcb9432301421b`

Occurrences: UI-78d31de9-9204ec-L0273-C089. Source status: `translation_ready_but_integration_pending`.

```json
{
  "template": "Só é possível excluir um registro concluído. Registros em andamento e o Focus atual não podem ser excluídos."
}
```

### `tracker.draft.8b4e4ed2b5d4ff15bfbc`

Occurrences: UI-78d31de9-9204ec-L0415-C046, UI-78d31de9-9204ec-L0415-C110, UI-78d31de9-9204ec-L0415-C178. Source status: `translation_ready_but_integration_pending`.

```json
{
  "variants": [
    {
      "when": "picked.size == 1",
      "translation_pt_BR": "“{starterTitle}” agora pode ser iniciado com um toque."
    },
    {
      "when": "picked.size != 1",
      "translation_pt_BR": "Pronto: {starterCountPhrase} para iniciar rapidamente."
    }
  ],
  "plural_forms": {
    "starterCountPhrase": {
      "count": "picked.size",
      "one": "{count} atividade",
      "other": "{count} atividades"
    }
  },
  "locale_plural_rule": "pt-BR CLDR one/other; preserve starterTitle exatamente como rótulo de catálogo/usuário."
}
```

### `tracker.draft.52c08c717c95f8409a5e`

Occurrences: UI-78d31de9-9204ec-L0524-C095, UI-78d31de9-9204ec-L0525-C055, UI-78d31de9-9204ec-L0525-C085, UI-78d31de9-9204ec-L0525-C118, UI-78d31de9-9204ec-L0526-C071, UI-78d31de9-9204ec-L0526-C107. Source status: `translation_ready_but_integration_pending`.

```json
{
  "template": "{goalName}{goalLimitSuffix}",
  "variants": [
    {
      "when": "direction == MINIMUM",
      "translation_pt_BR": "{goalName} · no mínimo {targetAmount}{periodSuffix}"
    },
    {
      "when": "direction == MAXIMUM",
      "translation_pt_BR": "{goalName} · no máximo {targetAmount}{periodSuffix}"
    }
  ],
  "enum_variants": {
    "periodSuffix": {
      "DAY": " por dia",
      "WEEK": " por semana",
      "MONTH": " por mês",
      "FIXED": ""
    },
    "metric": {
      "DURATION_MS": "duração formatada pelo locale",
      "COUNT": "número localizado + substantivo no plural pt-BR"
    }
  },
  "amount_format": {
    "DURATION_MS": "Use a duração localizada calculada do valor canônico em ms.",
    "COUNT": {
      "one": "{count} vez",
      "other": "{count} vezes"
    }
  },
  "locale_plural_rule": "pt-BR CLDR one/other; preserve goalName exatamente como conteúdo escrito pelo usuário e não altere target/period values."
}
```

### `tracker.draft.74f8fef1fa7615aefbe3`

Occurrences: UI-78d31de9-9204ec-L0528-C043, UI-78d31de9-9204ec-L0529-C043, UI-78d31de9-9204ec-L0530-C040, UI-78d31de9-9204ec-L0531-C042, UI-78d31de9-9204ec-L0533-C073. Source status: `translation_ready_but_integration_pending`.

```json
{
  "variants": [
    {
      "when": "GoalStatus.MINIMUM_PENDING",
      "translation_pt_BR": "Faltam {amount}"
    },
    {
      "when": "GoalStatus.MINIMUM_REACHED",
      "translation_pt_BR": "Meta atingida"
    },
    {
      "when": "GoalStatus.WITHIN_LIMIT",
      "translation_pt_BR": "Dentro do limite"
    },
    {
      "when": "GoalStatus.LIMIT_EXCEEDED",
      "translation_pt_BR": "Acima do limite em {amount}"
    }
  ],
  "suffix_variants": [
    {
      "when": "p.uncertain == true",
      "translation_pt_BR": ", inclui tempo com duração desconhecida"
    },
    {
      "when": "false",
      "translation_pt_BR": ""
    }
  ],
  "amount_format": "Formate {amount} como duração ou contagem conforme a métrica; preserve a quantidade.",
  "suffix_rule": "Acrescente o sufixo apenas quando p.uncertain == true."
}
```

### `tracker.draft.57150809b5bd9061299a`

Occurrences: UI-78d31de9-9204ec-L0710-C052. Source status: `translation_ready_but_integration_pending`.

```json
{
  "template": "Catálogo atualizado."
}
```

### `tracker.draft.c4e3c99fe51c321a4a25`

Occurrences: UI-7bf9337c-b13852-L0036-C023. Source status: `translation_ready_but_integration_pending`.

```json
{
  "template": "Substituição completa dos registros locais, atividades, favoritos, metas e configurações. Os novos dados locais serão removidos.",
  "warning_rule": "Manter explícito que a substituição é completa, nomear todos os tipos de dados e avisar que os novos dados locais serão removidos."
}
```

### `tracker.draft.83a4e62d2526d49dcc2d`

Occurrences: UI-794ce38c-76c989-L0088-C135, UI-794ce38c-76c989-L0089-C159. Source status: `translation_ready_but_integration_pending`.

```json
{
  "template": "Sem especificação",
  "use": "fallback localizado para seleção não classificada; não salvar como nome de usuário/catálogo."
}
```

### `tracker.draft.8f81b162870e4a56abe0`

Occurrences: UI-fb60e258-5b05e6-L0038-C048, UI-fb60e258-5b05e6-L0038-C100, UI-fb60e258-5b05e6-L0039-C037, UI-fb60e258-5b05e6-L0039-C107, UI-fb60e258-5b05e6-L0039-C138. Source status: `translation_ready_but_integration_pending`.

```json
{
  "variants": [
    {
      "when": "FocusMode.RECOVERY",
      "translation_pt_BR": "Focus: é preciso ajustar o horário"
    },
    {
      "when": "FocusMode.DUE",
      "translation_pt_BR": "Focus: o intervalo terminou; escolha a próxima etapa"
    },
    {
      "when": "FocusMode.PAUSED",
      "translation_pt_BR": "Focus pausado"
    },
    {
      "when": "FocusMode.RUNNING && FocusPhase.WORK",
      "translation_pt_BR": "Focus: intervalo de trabalho"
    },
    {
      "when": "FocusMode.RUNNING && FocusPhase.BREAK",
      "translation_pt_BR": "Focus: pausa"
    }
  ]
}
```

### `tracker.draft.1e318cac7a56777b5fd2`

Occurrences: UI-8949ea80-2c2906-L0505-C055, UI-8949ea80-2c2906-L0505-C092, UI-8949ea80-2c2906-L0505-C128, UI-8949ea80-2c2906-L0505-C164. Source status: `translation_ready_but_integration_pending`.

```json
{
  "variants": [
    {
      "when": "Mode.IDLE",
      "translation_pt_BR": "Cronômetro parado"
    },
    {
      "when": "Mode.RUNNING",
      "translation_pt_BR": "Registro em andamento"
    },
    {
      "when": "Mode.PAUSED",
      "translation_pt_BR": "Cronômetro pausado"
    },
    {
      "when": "Mode.RECOVERY",
      "translation_pt_BR": "É preciso ajustar o horário"
    }
  ]
}
```

## Blocked unit retained without a translation

- Parent key: `tracker.draft.d7bacc8fa4bed5ab16cb`
- Occurrences: UI-9eb89e6c-cf8364-L0279-C025, UI-9eb89e6c-cf8364-L0279-C210
- Reason: `{'code': 'dynamic_import_error_and_warning_messages_have_no_locale_contract', 'detail': 'The complete dialog interpolates preview.errors.take(30) and preview.warnings verbatim. At pinned baseline, HistoryTransfer creates free-form English strings containing row numbers and CoreError.message (e.g. “Row N: …”); they are not stable typed translation units. Translating only the outer Russian shell would leave arbitrary English source/error text visible.', 'required_context': 'Provide stable typed import issue IDs with typed row number/data arguments for every HistoryTransfer error and warning producer, or route raw detail into a diagnostic-only panel and display a localized summary. Until then the nested list portion cannot be declared translator-ready.', 'partial_ready_material': 'Outer labels/counts, preformatted import rows and final additive-vs-full-restore safety distinction are specified in resolved_source_recipe; this blocker applies to firstErrors/warnings nested payloads only.'}`
- Exact Russian source, recipe, occurrence IDs, and record hash are retained in the JSON. No Portuguese translation was inferred.
