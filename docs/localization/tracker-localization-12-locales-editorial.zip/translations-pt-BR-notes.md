# Tracker UI translation draft: pt-BR

## Scope and locale

This is an editorial translation draft for Brazilian Portuguese (`pt-BR`) only. It is not a universal Portuguese translation, does not claim coverage for Portuguese as used in Portugal (`pt-PT`), and does not establish that the app currently supports or ships this locale.

The immutable source is `translation-units.json`, SHA-256 `285e196dac220a2d3e95ffed48034bc04713d7e29995d8b8aedf7cb3e4cf6324`. The draft includes all 376 units whose source status is `ready_for_translation`, with all 402 source variants. Each record retains its exact draft key, source text, condition, occurrence IDs, typed placeholder metadata, and source-text hash. The source file was not edited.

## Exclusions

- `needs_composition`: 49 units, listed separately in `translations-pt-BR.json`. These require a composed message, locale-aware plural/format logic, typed state/error mapping, or other frontend integration context before a safe translation can be proposed. No speculative copy has been supplied.
- `non_translatable`: 5 units, listed separately in `translations-pt-BR.json`. These are protected brand/domain data or formatting rules rather than ordinary localized UI strings. Their source material and notes remain available in the excluded records.

## Editorial choices

- Use conversational Brazilian Portuguese with informal `você`-oriented copy.
- Keep `atividade` for activity, `cronômetro` for timer, `registro` for record, `histórico` for history, `cópia de segurança` for backup, and `fuso horário dos relatórios` for the report time zone.
- Keep the existing feature name `Focus`, product/brand names, identifiers, locale/data standards and technical names such as `(not)AI`, `Toggl`, `Clockify`, `Onest`, `CSV`, `JSON`, `IANA`, `ISO-8601`, `DB`, `WAL` and `SHM` as written.
- Preserve user/catalog/runtime content inside its exact source placeholder. Preserve Kotlin interpolation, simple `$name` placeholders, `%s` formatting tokens, and all source conditions; do not translate dynamic values or enum/wire conditions.
- Keep consequential wording complete, including export/restore/replacement and data-loss warnings. For example, the existing-history report-zone notice, the complete replacement confirmation, and the restore preview retain their full stated effects and safeguards.

## Validation and limits

Programmatic validation confirms: source SHA-256 matches; 376/376 ready draft keys are present; 402/402 source variants and conditions are preserved; all source occurrence IDs and per-unit hashes are retained; and all 64 placeholder/format-token occurrences match source multisets per variant. No code or app pages were edited. No build, runtime locale QA, or device testing was performed. This remains an editorial draft for frontend and Brazilian Portuguese review before any implementation.
