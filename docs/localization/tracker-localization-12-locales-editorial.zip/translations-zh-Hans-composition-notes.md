# zh-Hans composed UI copy — editorial notes

Status: completed Simplified Chinese editorial draft for 48 ready composition recipes / 101 occurrences. The single CSV import-preview unit remains blocked (2 occurrences); no partial translation was supplied. All entries remain integration-pending. This draft does not claim that a runtime resource, API, app integration, or device QA exists. `zh-Hans` does not establish `zh-Hant` readiness; Traditional Chinese remains a separate future locale package.

## Inputs and integrity

- `composition-resolution.json` — SHA-256 `af2648725aeab5817ab872a058149dcd55954e179db25c6e40d9a2e59616cfab`
- `translation-units.json` — SHA-256 `285e196dac220a2d3e95ffed48034bc04713d7e29995d8b8aedf7cb3e4cf6324`
- `composition-correction-overlay.json` — SHA-256 `6aee8e082c14f079d2b6e83de231bbbc92e6a096724deed10894ccf962b1a240`
- `translation-semantic-context.json` — SHA-256 `cf35e1042130b9c228f687427df14a9bb110a7fe0359000a7e6e74c75a1ee72b`
- Final `translations-zh-Hans-composition.json` — SHA-256 `c6eeb9f2a7cc9aa60bec7d7f93f5769bedbd4a543ab1a78373c5f51a440a5a04`
- Existing base `translations-zh-Hans.json` was not modified; its SHA-256 remains `50fa4e35c9e2d458ca72913d5a0e009815cd37ce5d726fff7d730dacf3c6ca0e`.

The composition output preserves the original Russian source objects, baseline resolved recipes, typed arguments, evidence, source-record hashes, source order, and occurrence IDs. The two correction records are appended separately as overlay provenance and replacement contracts. Each records canonical SHA-256 values for the original Russian object, baseline recipe, replacement contract, and source correction record. Canonical object hashes use sorted-key compact UTF-8 JSON.

## Applied overlay corrections

- `tracker.draft.f4e3d7be631be3107e29`: the Chinese panel title is `技术界面{roomSchemaSuffix}`. The optional suffix is exactly ` · Room {roomSchemaVersion}` only when verified target-build Room metadata is available; otherwise it is empty. The translated title does not hardcode Room 5, Room 6, or JSON 8. The replacement contract distinguishes the Room schema version from the JSON backup format version. Final-target SHA rebase and metadata verification are still required before integration.
- `tracker.draft.1a4d6d93d1b328fa3369`: the corrected template uses `{consequence}`, `{sessions}`, `{segments}`, `{goals}`, and one `{unfinishedDataSentence}` slot. The copied replacement contract maps segments to `preview.segments` and enumerates all four `unfinishedTail` / `unfinishedFocus` combinations. Each single-flag case explains that restored time is unknown and must be supplied. The both-true case uses one combined warning with one unknown-time consequence. The consequence is reused exactly once from `tracker.draft.c4e3c99fe51c321a4a25`.

The exact earlier Russian source and baseline recipe remain in their original source fields; they were not overwritten by the correction. The overlay is append-only and still requires rebase to the final target build before integration.

## Editorial and semantic decisions

- Chinese quantity branches use only CLDR `other`; `{count}` and other typed placeholders remain present. Source conditions, error codes/keys, enum identifiers, typed arguments, and source expressions are copied without localization.
- The backup-history fallback says that no backup has ever been created from this phone (`此手机尚未创建过备份。`); it does not describe whether a file currently exists on the device.
- The backup restore preview preserves separately saved current data, loss of records created after the selected backup, and the distinction between unfinished timer and Focus intervals whose time will be unknown.
- The CSV import preview key `tracker.draft.d7bacc8fa4bed5ab16cb` remains blocked because its row-summary/error/warning composition is not fully translator-safe. Its source contract and both occurrence IDs are retained. The contextual evidence that CSV append imports rows into app history is noted; no CSV file is implied to be modified.
- Focus and Room remain product/technical names. User-entered/catalog content, identifiers, zone IDs, and raw codes are not translated.

## Local validation

Pure data checks only; no app, runtime, build, or device validation was run. Validation confirmed 49 exact parent units; 48 ready translations / 101 occurrences; 1 blocked CSV unit / 2 occurrences; all 103 source occurrences present exactly once; exact source, condition, enum, and typed-argument preservation; placeholder-name coverage for all 46 uncorrected ready units and both correction contracts; four restore-flag cases; `preview.segments` mapping; Room suffix behavior; and Chinese `other` plural forms. The output SHA above is after validation. Integration/release readiness is not implied.
