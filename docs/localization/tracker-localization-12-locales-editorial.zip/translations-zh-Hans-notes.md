# Tracker 简体中文翻译 — 已准备切片

- 源清单：`translation-units.json`
- 源清单 SHA-256：`285e196dac220a2d3e95ffed48034bc04713d7e29995d8b8aedf7cb3e4cf6324`
- 源快照：`translations-zh-Hans.json` 保留全部 24 个源文件 blob 哈希。
- 目标语言：`zh-Hans`（简体中文）。`zh-Hant`（繁体中文）是单独的后续语言，本稿不包含，也不代表其已完成。
- 状态：**供简体中文母语审校及 UI 检查的完整编辑稿**，不是生产就绪声明，也不表示应用已支持此语言。
- 覆盖范围：376/376 个 `ready_for_translation` 单元、402/402 个源文本变体均已翻译；其中 25 个单元含 51 个条件变体；没有 ready 单元被阻塞。
- 剩余项明确保留为未翻译：49 个 `needs_composition` 和 5 个 `non_translatable`（共 54 个）。状态和源内容均保留，没有补写缺失语义。
- Occurrence ID：清单中的 563/563 个 ID 均在输出中原样保留且恰好分配一次：437 个属于已翻译的 ready 单元，126 个属于未翻译剩余项。
- 自动校验：源清单 SHA-256、376 个 ready key 的覆盖与顺序、402 个准确源文本及其 UTF-8 SHA-256、变体条件、occurrence IDs、占位符 token、类型化占位符元数据和完整 ID 覆盖：**通过**。所有 49+5 个剩余项的状态及源内容均与输入一致。
- 编辑约定：`Focus` 作为功能名称保留；`Start`、`Switch` 等技术 action/wire 标签不翻译。品牌 `(not)AI`、用户或目录输入的活动名称、占位符和标识符、`ID`、`target`、`duration`、CSV/JSON、ISO-8601、时区 ID、Toggl、Clockify、Onest、DB/WAL/SHM 等代码、文件格式、专有名词及动态值保持可识别。界面中普通的开始/切换操作仍按上下文翻译。
- 重要语义：恢复操作可能完全替换当前数据；预览、替换前保存并核验 DB/WAL/SHM 哈希、保留旧副本以及回滚副本的后果和限制均有明确表达。未知时长不会被猜测；未补充前不计入汇总。CSV 历史记录导入与完整 JSON 备份/CSV 报表之间的区别保留。更改报表时区会改变日界线和报表视图，但不会更改实际时间段或单独保存的目标时区。调用 undo 的“Отменено”按撤销既有操作翻译为“已撤销”，不是取消。
- 建议复核：简体中文母语审校、术语一致性、短标签长度与截断、动态占位符的 Android 呈现、无障碍标签和各界面布局。覆盖检查为静态数据校验；未执行 build、测试、应用启动、运行时/通知渲染或设备本地化 QA。
- 范围：仅新增本地翻译 JSON 与此说明。未改应用代码、运行时资源、Pages、访问权限或源清单。此稿不覆盖完整应用，也不覆盖 zh-Hant。

## 独立完整复核后的定稿

- 已逐项阅读 `translation-review-ar-zh-Hans.json` 中全部 6 条 zh-Hans findings，并对照静态源上下文进行裁决；阿拉伯语 findings、阿拉伯语包及 review 原文件均未修改。
- 裁决记录：`translation-review-zh-Hans-adjudication.json`。其中保留每条 review 原始 finding 的 source/current/suggested/reason，并增加 old/final translation、裁决和理由、条件、源文 SHA-256、occurrence IDs、placeholder tokens 与类型化占位符元数据。
- 六项均采纳其语义澄清；ZH-02 的最终措辞略作编辑以自然表达“向应用追加 CSV 导入记录”。ZH-01 明确导出取消后已准备的文件仍保留，不表示新导出文件成功保存。ZH-03/04 使用“为当前记录指定活动”及“切换活动或指定活动”，明确 PickMode.LABEL 将活动赋给当前活动记录，而非添加描述。
- ZH-05 将面向用户的 `offset` 提示译为“时区偏移量”；实际日期/时间格式、ISO、程序表达式 `${offset+1}` 等 wire/placeholder 值保持原样。ZH-06 将静态通用示例 `listening` 本地化为“聆听”；它不是用户名称、代码或 wire value。
- 复核输入 review SHA-256：`ae6391e0d93ec1bdf2b80e0ca717fffd241db78f143c875f86770079d33c5ffe`。最终 zh-Hans JSON SHA-256：`50fa4e35c9e2d458ca72913d5a0e009815cd37ce5d726fff7d730dacf3c6ca0e`。
- 更改仅限上述 6 个 zh-Hans `translation` 字段。定稿后再次完整结构核验：376/376 ready units、402/402 variants，所有 source text、source-text hashes、conditions、occurrence IDs、placeholders 和类型化 placeholder metadata 原样保留；563 个源 occurrence IDs 在已翻译单元及 54 个未翻译剩余项中恰好出现一次。49 个 `needs_composition` 与 5 个 `non_translatable` 状态和源内容未变；`zh-Hant` 仍明确排除。
