# Tracker UI localization: source inventory

Baseline: [Android 0.11.0, ee0ab1f52d07c9957f9a198312d6584aebc9d170](https://github.com/8Dionysus/not-ai-time-tracker/commit/ee0ab1f52d07c9957f9a198312d6584aebc9d170). Full Git tree: 422 entries, 341 blobs, not truncated. This is a static source inventory, not device/runtime proof.

## Scope and coverage

The complete production app source set at this baseline was fetched read-only and scanned: 30 app Kotlin files, 91 Android resource XML files, the manifest, and six Gradle/build configuration files. Eighteen core Kotlin files were also read to identify UI-consumed status/fallback text. No Java source files are present in the production app tree. No build, app run, or tests were performed.

The JSON manifest contains all 146 processed source paths with blob SHA/size, plus every other tracked blob path/SHA with its exclusion reason. It includes 563 exact source occurrences/references: 517 Cyrillic app Kotlin string occurrences, 11 independently reviewed Latin/brand UI candidates, 3 locale-sensitive date-format patterns, 12 core-produced surface/display strings, 9 Android string-resource values, and 11 XML/manifest @string references. IDs include exact line and column. Five technical exception strings are conservatively tagged indirect/possible. The manifest holds full context; this index is intentionally compact.

## Localization target

The required product direction is full UI localization, including Spanish and popular languages. The linked contract's baseline tags are ru/ru-RU, en/en-US, es/es-419/es-MX, pt/pt-BR/pt-PT, fr-FR, de-DE, it-IT, zh-Hans, zh-Hant, ja-JP, ko-KR, ar, hi-IN. These are requirements, not a claim that this baseline currently supports them.

## Read-first groups for Opus

- Main Compose screens and accessibility semantics: [TimerScreen.kt](https://github.com/8Dionysus/not-ai-time-tracker/blob/ee0ab1f52d07c9957f9a198312d6584aebc9d170/app/src/main/kotlin/dev/notai/tracker/android/ui/TimerScreen.kt) (62 occurrences), [OverviewScreen.kt](https://github.com/8Dionysus/not-ai-time-tracker/blob/ee0ab1f52d07c9957f9a198312d6584aebc9d170/app/src/main/kotlin/dev/notai/tracker/android/ui/OverviewScreen.kt) (19), [PickerSheet.kt](https://github.com/8Dionysus/not-ai-time-tracker/blob/ee0ab1f52d07c9957f9a198312d6584aebc9d170/app/src/main/kotlin/dev/notai/tracker/android/ui/PickerSheet.kt) (30), [Forms.kt](https://github.com/8Dionysus/not-ai-time-tracker/blob/ee0ab1f52d07c9957f9a198312d6584aebc9d170/app/src/main/kotlin/dev/notai/tracker/android/ui/Forms.kt) (38), [SettingsScreen.kt](https://github.com/8Dionysus/not-ai-time-tracker/blob/ee0ab1f52d07c9957f9a198312d6584aebc9d170/app/src/main/kotlin/dev/notai/tracker/android/ui/SettingsScreen.kt) (86), App (28), Components (1), TrackerViewModel (51). This includes visible text, action labels, empty/error/confirmation states, dynamic templates and semantics labels.
- Legacy/technical shell: [TechnicalActivity.kt](https://github.com/8Dionysus/not-ai-time-tracker/blob/ee0ab1f52d07c9957f9a198312d6584aebc9d170/app/src/main/kotlin/dev/notai/tracker/android/TechnicalActivity.kt) (151). It carries CSV mapping, measurements, calendar/recovery workflows, dialogs/status, technical errors, and a few English-only controls (“Start”, “Switch”, “Preview”, “OK”). Treat it as user-visible and localize it.
- Outside-app surfaces: FloatingTimerService (14, overlay including toasts), FocusSignals (3, notification/channel), SurfaceViews (18, notification/widget/RemoteViews), TimerSurfaces (11, shortcut/action labels), plus XML references in notification/widget layouts, shortcuts, widget metadata and manifest.
- Locale-sensitive presentation: [Presentation.kt](https://github.com/8Dionysus/not-ai-time-tracker/blob/ee0ab1f52d07c9957f9a198312d6584aebc9d170/app/src/main/kotlin/dev/notai/tracker/android/ui/Presentation.kt) has hardcoded Russian DateTimeFormatter locale/patterns, Russian duration units/plural forms, and an eight-branch error-copy mapper (ErrorCode.STALE, INVALID_INTERVAL, OVERLAP, RECOVERY_REQUIRED, STORAGE, UNSUPPORTED_IMPORT, INVALID_INPUT, unknown). The plural forms are split/hardcoded and need CLDR/platform plural handling; interpolated exception messages should not be exposed as untyped localized copy.
- Core values consumed by UI: Backup.kt confirmation consequence; Choices.kt unclassified fallback; Focus.kt Focus state summaries; Tracker.kt timer status labels. Keep domain state/error codes stable and render through app-localized resources.

Exact keys and context are in [the JSON manifest](./ui-localization-inventory.json).

## Resource and locale gaps in this baseline

- [app/src/main/res/values/strings.xml](https://github.com/8Dionysus/not-ai-time-tracker/blob/ee0ab1f52d07c9957f9a198312d6584aebc9d170/app/src/main/res/values/strings.xml) is the only app string-value file: 9 values. There are no plural/string-array definitions and no alternate-language string-resource sets in the full tree.
- XML layouts/manifest have no inline human text/accessibility literals; they reference string keys. Manifest sets `supportsRtl="true"`, but there is no `localeConfig` attribute or locale-config XML in the tree. `supportsRtl` is not proof every screen is mirrored or accessible.
- `Presentation.kt` pins `Locale.forLanguageTag("ru")`; date patterns and custom Russian plural selection are statically locale-specific.
- Keep the app UI locale separate from the report time zone: localize presentation only; do not change stored instants, event/report-day semantics, timer state, units, IDs or original user text.
- Manifest/resource refs cover app/launcher/technical labels, widget description, shortcut, quick-start/all-activities labels, and start/pause actions. The JSON gives every exact line/reference.

## Scope boundary and exclusions

- Do not translate/include the 1,918 activity-type catalog entries. `catalog/runtime-catalog.json`, `catalog/manifest.json`, `catalog/compatibility.json`, catalog bootstrap metadata and the generated ActivityGlyphs stable-ID mapping remain a separate content contract. UI occurrences that display live catalog/custom labels are dynamic content, not hardcoded UI strings.
- Excluded with paths and blob SHAs: test/fixture source, Room schema snapshots, committed evidence/build/test outputs, documentation, scripts and sample data, binary font files, license text, and catalog content. Binary/catalog payloads are intentionally unread; no in-scope production source was unread.
- IDs, SQL, property/JSON/CSV schemas and headers, MIME types, filenames, URIs, stable catalog IDs, vector path data, color/theme names, logs and build metadata are not translator copy. Full-tree classification and reasons are in the JSON.

## Limits

This closes the static tracked production-source scope for the pinned commit, not runtime/device behavior. It does not prove full call-graph visibility, generated manifest/AAB contents, TalkBack/RTL layout, state preservation after locale switching, or translated-language completeness. Review the five low-confidence TechnicalActivity exception strings at lines 127, 143, 321, 539 and 542 in the JSON; they may surface raw backend errors and should be mapped by stable error code/typed arguments.
